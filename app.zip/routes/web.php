<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Route::get('/', function () {
    return view('welcome');
});*/

Route::get('/', 'UserController@index');
Route::get('index', 'UserController@index');
Route::post('login', 'UserController@login');
Route::get('logout', 'UserController@logout');

Route::get('dashboard', 'UserController@dashboard');
Route::get('create-diary', 'DiaryEntryController@create');
Route::post('create-diary', 'DiaryEntryController@create');
Route::post('create-diary-entry', 'DiaryEntryController@store');
Route::get('dairy-entry/{id}', 'DiaryEntryController@edit');
Route::post('update-entry/{id}', 'DiaryEntryController@update');

Route::get('dairy', 'DiaryEntryController@index');

Route::get('dairy/{id}/get', 'DiaryEntryController@getDairy');
Route::post('dairy/{id}/edit', 'DiaryEntryController@updateEntry');

Route::get('delete-entry/{id}', 'DiaryEntryController@deleteEntry');
Route::get('view-entry/{id}', 'DiaryEntryController@viewEntry');

Route::post('view-diary-entry', 'DiaryEntryController@viewDiaryEntry');


Route::post('edit-create-diary', 'DiaryEntryController@dateDiaryEntry');

Route::get('goal', 'GoalController@index');
Route::get('tag', 'TagController@index');
Route::get('plan', 'PlanController@index');

Route::get('diary-entries/{id}', 'DiaryEntryController@byDateEntry');

Route::post('wellness-edit', 'DiaryEntryController@wellnessedit');
Route::post('market-form-edit', 'DiaryEntryController@marketedit');
Route::post('market-form-add', 'DiaryEntryController@marketadd');
Route::post('todo-form-edit', 'DiaryEntryController@todoeditfrm');
Route::post('todo-form-add', 'DiaryEntryController@todoaddfrm');
Route::post('report-form-add', 'DiaryEntryController@reportaddfrm');
Route::post('report-form-edit', 'DiaryEntryController@reporteditfrm');
Route::post('notes-form-edit', 'DiaryEntryController@noteseditfrm');
Route::post('notes-form-add', 'DiaryEntryController@notesaddfrm');
Route::post('idea-form-edit', 'DiaryEntryController@ideaeditfrm');
Route::post('idea-form-add', 'DiaryEntryController@ideaaddfrm');
Route::post('hate-form-edit', 'DiaryEntryController@hateeditfrm');
Route::post('like-form-edit', 'DiaryEntryController@likeeditfrm');
Route::post('home-form-edit', 'DiaryEntryController@homeeditfrm');
Route::post('home-form-add', 'DiaryEntryController@homeaddfrm');
Route::post('routine-form-edit', 'DiaryEntryController@routineformedit');