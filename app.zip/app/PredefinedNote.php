<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PredefinedNote extends Model
{
    //
}
