<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class DiaryEntry extends Model
{
	protected $fillable = ['EntryDate'];

	/* Added new entry */
	public function store($request){
		$EntryDate = $request['EntryDate'];
		$userId = session()->get('UserLoginId');
		$Date = date('Y-m-d');
		if($EntryDate!=''){	
						
			$EntryRecord = DB::table('diary_entries')
				->where('EntryDate',$EntryDate)
				->where('UserId',$userId)
				->get();
				if(!empty($EntryRecord)){
					if(isset($EntryRecord[0]->EntryId)!=''){
						return 0;
					}else{
						$InsertID = DB::table('diary_entries')->insertGetId(
						array('EntryDate' => $EntryDate,
							 'UserId' => $userId,
							 'created_at' => $Date,
							 
							 )
					);
					return $InsertID;
					}
					
				}
				
		}return 0;

	}
	/* Get record */
	public function getRecord($type){
		$PredefineDetail = DB::table('predefined_notes')
			->where('PredefinedNoteType',$type)
			->where("IsActive",'1')
			->get();
		return $PredefineDetail;
	}
	/* Get record by Id */
	public function getRecordById($tablename,$parameter,$value){
		$PredefineDetail = DB::table($tablename)
			->where($parameter,$value)				
			->get();
		return $PredefineDetail;
	}
	/* Get record by date */
	public function getRecordByDate(){
		$PredefineDetail = DB::table('diary_entries')
			->whereNull('PredefinedNoteId')	 
			->get();
		return $PredefineDetail;
	}
	/* Count simple notes */
	public function CountSimpleNotes($userId,$date){
		$PredefineDetail =  DB::table('diary_entries')
			->where('UserId',$userId)
			->where('EntryDate',$date)				
			->whereNotNull('PredefinedNoteId')
			->get();
			$totalnote = count($PredefineDetail);
			
			$PredefineDetail1 =  DB::table('diary_entries')
			->where('UserId',$userId)
			->where('EntryDate',$date)				
			->whereNull('PredefinedNoteId')
			 ->limit(1)
			->get();
			
			
			if(!empty($PredefineDetail1))
			{
					if(isset($PredefineDetail1[0]->EntryId)!=""){
						$ids = $PredefineDetail1[0]->EntryId;
						$hate =  DB::table('diary_entry_todos')
						->where('EntryId',$ids)
						->where('PredefineType','7')				
						->where('Title','<>','')
						->get();
						$hates = count($hate);
						
						$like =  DB::table('diary_entry_todos')
						->where('EntryId',$ids)
						->where('PredefineType','8')				
						->where('Title','<>','')
						->get();
						$likes = count($like);
						$totlasimplenote = $totalnote + $hates +$likes;
						
					return	$retun = $totlasimplenote.'-'.$ids;
						
					}else{
						return $retun = '0-0';
					}
					return $retun = '0-0';
			}
			
			
	return $retun;
	}

	/* Count simple notes with status */
	public function CountSimpleNotesWithStatus($table,$para1,$val1,$para2,$val2,$para3,$val3){
		$PredefineDetail =  DB::table($table)
			->where($para1,$val1)
			->where($para2,$val2)				
			->where($para3,$val3)
			->get();
		$count = count($PredefineDetail);
		return $count;
			
	}
	/* Count simple notes without status */
	public function CountSimpleNotesWithoutStatus($table,$para1,$val1,$para2,$val2){
		$PredefineDetail =  DB::table($table)
			->where($para1,$val1)
			->where($para2,$val2)
			->get();
			$count = count($PredefineDetail);
		return $count;
			
	}
	/* Get record by date with limit  */
	public function getRecordByDateLimit($tablename,$para,$val){
		$PredefineDetail = DB::table($tablename)
			->where($para,$val)	
			->whereNull('PredefinedNoteId')
			->limit(1)	 //whereNotNull
			->get();
			
		return $PredefineDetail;
	}
	/* Get recode by date by userid , pre-define note Id */
	public function getRecordByDateByParamerer($tablename,$date,$userid,$parameter,$parameter1){
	 
		$PredefineDetail = DB::table($tablename)
			->where('EntryDate',$date)	
			->where('UserId',$userid)	
			->where('PredefinedNoteId',$parameter)	
			->where($parameter1,'1')				
			->get();
			
		return $PredefineDetail;
	}
	/* Insert function entry */
	public function added($request){
		if(isset($request['habit'])!=''){
		  $habit = $request['habit'];
		}else {
		  $habit = '';	
		}
		$EnterId = $request['EnterId'];
		$EntryDate = $request['EntryDate'];
		if(isset($request['marketing'])!=''){
		  $marketing = $request['marketing'];
		}else {
		  $marketing = '';	
		}
		
		if(isset($request['todotextnews'])!=''){
		  $todotextnews = $request['todotextnews'];
		  $todotextnews_array = array_map('current', $todotextnews);
		}else {
		  $todotextnews = array();	
		}
		if(isset($request['todostatusnews'])){
		   $todostatusnews = $request['todostatusnews'];
		   $todostatusnewss = array_map('current', $todostatusnews);
		}else{
			$todostatusnews = array();
			$todostatusnewss = array();
			
		}
		if(isset($request['report'])!=''){
		  $report = $request['report'];
		}else {
		  $report = '';	
		}
		if(isset($request['notes'])!=''){
		  $notes = $request['notes'];
		}else {
		  $notes = '';	
		}

		if(isset($request['createiveidea'])!=''){
		  $createiveidea = $request['createiveidea'];
		}else {
		  $createiveidea = array();	
		}
		$createiveidea = $request['createiveidea'];
		$createiveidea_array = array_map('current', $createiveidea);
		if(isset($request['ideaatus'])){
		   $ideaatus = $request['ideaatus'];
		   $ideaatuss = array_map('current', $ideaatus);
		}else{
			$ideaatus = array();
			$ideaatuss = array();			
		}
		if(isset($request['secondNotes'])!=''){
		  $secondNotes = $request['secondNotes'];
		}else {
		  $secondNotes = array();	
		}		  
	  
		if(isset($request['secondsimpleNotes'])!=''){			  
		  $secondsimpleNotes = $request['secondsimpleNotes'];
		   $secondsimpleNotes_array = array_map('current', $secondsimpleNotes);
		}else {
		  $secondsimpleNotes_array = array();	
		}
		
		if(isset($request['secondsimpleNotesstatus'])!=''){			  
		  $secondsimpleNotesstatus = $request['secondsimpleNotesstatus'];
		   $secondsimpleNotesstatus_array = array_map('current', $secondsimpleNotesstatus);
		}else {
		  $secondsimpleNotesstatus_array = array();	
		}
		
		if(isset($request['fivehatenote'])!=''){
		  $fivehatenote = $request['fivehatenote'];
		}else {
		  $fivehatenote = array();	
		}
		if(isset($request['fivelikenote'])!=''){
		  $fivelikenote = $request['fivelikenote'];
		}else {
		  $fivelikenote = array();	
		}
		if(isset($request['home'])!=''){
		  $home = $request['home'];
		}else {
		  $home = '';	
		}		 
	  $array = array_map('current', $todotextnews);
	  
	  	 
	 // -- primary habit
	 if(!empty($habit)){
		 $count = count($habit);	
		 for($i=0;$i<$count;$i++){			
			$InsertID = DB::table('diary_entry_todos')->insertGetId(
			array('PredefinedNoteId' => $habit[$i],
				 'EntryId' => $EnterId,
				 'IsActive' => '1',
				 'PredefineType'=>'1'					 
				 )
			);
		}
	 }
	 
	 if(isset($request['todotextnews'])!=''){
		  $todotextnews = $request['todotextnews'];
		  $todotextnews_array = array_map('current', $todotextnews);
		}else {
		  $todotextnews = array();	
		}
		if(isset($request['todostatusnews'])){
		   $todostatusnews = $request['todostatusnews'];
		   $todostatusnewss = array_map('current', $todostatusnews);
		}else{
			$todostatusnews = array();
			$todostatusnewss = array();
			
		}
		 $array = array_map('current', $todotextnews);
	  // -- to do list 
		if(!empty($todotextnews_array)){
			$count = count($todotextnews_array);	
			for($i=0;$i<$count;$i++){
				if(isset($todotextnews_array[$i])){		
					if(isset($todostatusnewss[$i])==''){					
						$InsertID = DB::table('diary_entry_todos')->insertGetId(
						array('PredefinedNoteId' => '2',
							'Title' => $todotextnews_array[$i],
							'EntryId' => $EnterId,
							'IsActive' =>  '0',
							'PredefineType'=>'3'				 
							)
						);				

					}else{					
							$InsertID = DB::table('diary_entry_todos')->insertGetId(
							array('PredefinedNoteId' => '2',
							'Title' => $todotextnews_array[$i],
							'EntryId' => $EnterId,
							'IsActive' =>  $todostatusnewss[$i],
							'PredefineType'=>'3'				 
							)
						);
					}
				} 

			}
		}
	   
		if(isset($request['createiveidea'])!=''){
		  $createiveidea = $request['createiveidea'];
		}else {
		  $createiveidea = array();	
		}
		$createiveidea = $request['createiveidea'];
		$createiveidea_array = array_map('current', $createiveidea);
		if(isset($request['ideaatus'])){
		   $ideaatus = $request['ideaatus'];
		   $ideaatuss = array_map('current', $ideaatus);
		}else{
			$ideaatus = array();
			$ideaatuss = array();
			
		}
		
		 if(!empty($createiveidea_array)){
		 $countsss = count($createiveidea_array);	
		 for($i=0;$i<$countsss;$i++){
			
			 if(isset($createiveidea_array[$i])){		
			if(isset($ideaatuss[$i])==''){					
					$InsertID = DB::table('diary_entry_todos')->insertGetId(
					array('PredefinedNoteId' => '2',
						 'Title' => $createiveidea_array[$i],
						 'EntryId' => $EnterId,
						 'IsActive' =>  '0',
						 'PredefineType'=>'4'				 
						 )
					);				
				
			}else{					
				$InsertID = DB::table('diary_entry_todos')->insertGetId(
				array('PredefinedNoteId' => '2',
					 'Title' => $createiveidea_array[$i],
					 'EntryId' => $EnterId,
					 'IsActive' =>  $ideaatuss[$i],
					 'PredefineType'=>'4'				 
					 )
				);
			 }
			} 
			
		}
	 }
	 
	 // -- second simple Notes footer left 2
	 
	  if(!empty($secondsimpleNotes_array)){
		 $count = count($secondsimpleNotes_array);	
		 for($i=0;$i<$count;$i++){		
			 
			 if(isset($secondsimpleNotes_array[$i])!=''){	
				 if(isset($secondsimpleNotesstatus_array[$i])==''){
					 $InsertID = DB::table('diary_entry_todos')->insertGetId(
					array('PredefinedNoteId' => '2',
						'Title' => $secondsimpleNotes_array[$i],
						 'EntryId' => $EnterId,
						 'IsActive' => '0',
						 'PredefineType'=>'5'			 
						 )
					);
				 }
				 else{
					 $InsertID = DB::table('diary_entry_todos')->insertGetId(
						array('PredefinedNoteId' => '2',
								'Title' => $secondsimpleNotes_array[$i],
								 'EntryId' => $EnterId,
								 'IsActive' => $secondsimpleNotesstatus_array[$i],
								 'PredefineType'=>'5'			 
								 )
						);
				}
			 }
			
		}
	 }
	  // -- secondNotes
	  
	  
		 if(!empty($secondNotes)){
			 $countss = count($secondNotes);	
			 for($i=0;$i<$countss;$i++){			
				$InsertID = DB::table('diary_entry_todos')->insertGetId(
				array('PredefinedNoteId' => $secondNotes[$i],
					 'EntryId' => $EnterId,
					 'IsActive' => '1',
					 'PredefineType'=>'2'					 
					 )
				);
			}
		 }
	 
	  
	 
		// 5 hate note
		  if(!empty($fivehatenote)){
			 $count = count($fivehatenote);	
			 for($i=0;$i<$count;$i++){			
				$InsertID = DB::table('diary_entry_todos')->insertGetId(
				array('PredefinedNoteId' => '1',
					 'Title' => $fivehatenote[$i],
					 'EntryId' => $EnterId,
					 'IsActive' => '0',
					 'PredefineType'=>'7'					 
					 )
				);
			}
		 }
		// 5 like note
		 if(!empty($fivelikenote)){
			 $count = count($fivelikenote);	
			 for($i=0;$i<$count;$i++){			
				$InsertID = DB::table('diary_entry_todos')->insertGetId(
				array('PredefinedNoteId' => '1',
					 'Title' => $fivelikenote[$i],
					 'EntryId' => $EnterId,
					 'IsActive' => '0',
					 'PredefineType'=>'8'					 
					 )
				);
			}
		 }
		// marketing entry
		 if(!empty($marketing)){
			 $count = count($marketing);
			 for($i=0;$i<$count;$i++){
				   DB::table('diary_entries')->insertGetId(
					array('EntryDate' => $EntryDate,
						 'UserId' => session()->get('UserLoginId'),
						 'PredefinedNoteId' => '2',
						 'NoteText' => $marketing[$i],
						 'PredefineNoteType'=>'1'					 
						 )
					);
			 }
			 
		}
		// report entry
		 if(!empty($report)){
			 $count = count($report);
			 for($i=0;$i<$count;$i++){
				   DB::table('diary_entries')->insertGetId(
					array('EntryDate' => $EntryDate,
						 'UserId' => session()->get('UserLoginId'),
						 'PredefinedNoteId' => '4',
						 'NoteText' => $report[$i],
						 'PredefineNoteType'=>'1'					 
						 )
					);
			 }
			  
		}
		// notes entry
		 if(!empty($notes)){
			 $count = count($notes);
			 for($i=0;$i<$count;$i++){
				   DB::table('diary_entries')->insertGetId(
					array('EntryDate' => $EntryDate,
						 'UserId' => session()->get('UserLoginId'),
						 'PredefinedNoteId' => '5',
						 'NoteText' => $notes[$i],
						 'PredefineNoteType'=>'1'					 
						 )
					);
			 }
		}
		// home entry
		 if(!empty($home)){
			 $count = count($home);
			 for($i=0;$i<$count;$i++){
				   DB::table('diary_entries')->insertGetId(
					array('EntryDate' => $EntryDate,
						 'UserId' => session()->get('UserLoginId'),
						 'PredefinedNoteId' => '11',
						 'NoteText' => $home[$i],
						 'PredefineNoteType'=>'1'					 
						 )
					);
			 }
			 
		}
		return 1;
		
	}

	/* Destroyed entry */
	public function destroyedEntry($tablename,$para,$value){			 
		DB::table($tablename)
		->where($para, $value)		    
		->delete();
		return 1;
	}
	/* Habit section Edit Entry */	
	public function habitedit($habit,$id){		 
		if(!empty($habit)){
		 $count = count($habit);	
		 for($i=0;$i<$count;$i++){			
			$InsertID = DB::table('diary_entry_todos')->insertGetId(
			array('PredefinedNoteId' => $habit[$i],
				 'EntryId' => $id,
				 'IsActive' => '1',
				 'PredefineType'=>'1'					 
				 )
			);
		}
		}
		return 1;
	}
	/* Routine Habit section Edit Entry */	
	public function routineedit($secondNotes,$id){		 
		if(!empty($secondNotes)){
		 $count = count($secondNotes);	
		 for($i=0;$i<$count;$i++){			
			$InsertID = DB::table('diary_entry_todos')->insertGetId(
			array('PredefinedNoteId' => $secondNotes[$i],
				 'EntryId' => $id,
				 'IsActive' => '1',
				 'PredefineType'=>'2'					 
				 )
			);
		}
		}
		return 1;
	}
	/* Market section Edit Entry */	
	public function marketedit($marketing,$mynewdate){		 
		if(!empty($marketing)){
		 $count = count($marketing);	
		
			$EntryRecord = DB::table('diary_entries')
			->where('EntryDate',$mynewdate)
			->where('PredefineNoteType','1')
			->get();
			if(!empty($EntryRecord)){
				if(isset($EntryRecord[0]->EntryId)!=""){
					foreach($EntryRecord as $rec){
						$isd[]=$rec->EntryId;
					}
				 $cou = count($isd);
					for($i=0;$i<$cou;$i++){
						if(isset($marketing[$i])!=''){
							$title=$marketing[$i];
						}else{ $title='';}
						if($title!=''){}
						DB::table('diary_entries')
						   ->where('EntryId', $isd[$i])
							  ->update(
							   array( 
									 'EntryDate' => $mynewdate,
									 'UserId' => session()->get('UserLoginId'),
									 'PredefinedNoteId' => '2',
									 'NoteText' => $title,
									 'PredefineNoteType'=>'1'
									 )
							);
						}
					}
				}
			
			}
			return 1;
		}
		
	/* Market section add Entry */	
	public function marketedit1($marketing,$mynewdate){		 
		if(!empty($marketing)){
		 $count = count($marketing);	
		 for($i=0;$i<$count;$i++){			
			$InsertID = DB::table('diary_entries')->insertGetId(
			array('EntryDate' => $mynewdate,
				 'UserId' => session()->get('UserLoginId'),
				 'PredefinedNoteId' => '2',
				 'NoteText' => $marketing[$i],
				 'PredefineNoteType'=>'1'						 
				 )
			);
		}
		}
		return 1;
	}
	/* Hate section edit Entry */			
	public function hatesedit($fivehatenote,$EnterId){
		$count = count($fivehatenote);	
		
		$EntryRecord = DB::table('diary_entry_todos')
			->where('EntryId',$EnterId)
			->where('PredefineType','7')
			->get();
			if(!empty($EntryRecord)){
				if(isset($EntryRecord[0]->Id)!=""){
					foreach($EntryRecord as $rec){
						$isd[]=$rec->Id;
					}
					$cou = count($isd);
					for($i=0;$i<5;$i++){
						DB::table('diary_entry_todos')
						   ->where('Id', $isd[$i])
							  ->update(
							   array( 
									 'PredefinedNoteId' => '1',
									 'Title' => $fivehatenote[$i],
									 'EntryId' => $EnterId,
									 'IsActive' => '0',
									 'PredefineType'=>'7'
									 )
							);
					}
				}else{
					for($i=0;$i<5;$i++){			
						$InsertID = DB::table('diary_entry_todos')->insertGetId(
						array('PredefinedNoteId' => '1',
							 'Title' => $fivehatenote[$i],
							 'EntryId' => $EnterId,
							 'IsActive' => '0',
							 'PredefineType'=>'7'					 
							 )
						);
					}
				}
			}
			
		return 1;
	}

	/* Hate section add Entry */	
	public function hatesedit1($fivehatenote,$EnterId){
		$count = count($fivehatenote);	
		 for($i=0;$i<5;$i++){			
			$InsertID = DB::table('diary_entry_todos')->insertGetId(
			array('PredefinedNoteId' => '1',
				 'Title' => $fivehatenote[$i],
				 'EntryId' => $EnterId,
				 'IsActive' => '0',
				 'PredefineType'=>'7'					 
				 )
			);
		}
		return 1;
	}
	/* Like section edit Entry */	
	public function likeedit($fivelikenote,$EnterId){
		
		$count = count($fivelikenote);	
		
		$EntryRecord = DB::table('diary_entry_todos')
			->where('EntryId',$EnterId)
			->where('PredefineType','8')
			->get();
			if(!empty($EntryRecord)){
				if(isset($EntryRecord[0]->Id)!=""){
					foreach($EntryRecord as $rec){
						$isd[]=$rec->Id;
					}
					$cou = count($isd);
					for($i=0;$i<5;$i++){
						DB::table('diary_entry_todos')
						   ->where('Id', $isd[$i])
							  ->update(
							   array( 
									 'PredefinedNoteId' => '1',
									 'Title' => $fivelikenote[$i],
									 'EntryId' => $EnterId,
									 'IsActive' => '0',
									 'PredefineType'=>'8'
									 )
							);
					}
				}else{
					for($i=0;$i<5;$i++){			
						$InsertID = DB::table('diary_entry_todos')->insertGetId(
						array('PredefinedNoteId' => '1',
							 'Title' => $fivelikenote[$i],
							 'EntryId' => $EnterId,
							 'IsActive' => '0',
							 'PredefineType'=>'8'					 
							 )
						);
					}
				}
			}
			
		return 1;
	}
	/* Like section add Entry */	
	public function likeedit1($fivelikenote,$EnterId){
		$count = count($fivelikenote);	
		 for($i=0;$i<5;$i++){			
			$InsertID = DB::table('diary_entry_todos')->insertGetId(
			array('PredefinedNoteId' => '1',
				 'Title' => $fivelikenote[$i],
				 'EntryId' => $EnterId,
				 'IsActive' => '0',
				 'PredefineType'=>'8'					 
				 )
			);
		}
		return 1;
	}

	/* Report section edit Entry */	
	public function reportedit($reports,$mynewdate){
		if(!empty($reports)){
		 $count = count($reports);	
		 for($i=0;$i<$count;$i++){			
			$InsertID = DB::table('diary_entries')->insertGetId(
			array('EntryDate' => $mynewdate,
				 'UserId' => session()->get('UserLoginId'),
				 'PredefinedNoteId' => '4',
				 'NoteText' => $reports[$i],
				 'PredefineNoteType'=>'1'						 
				 )
			);
		}
		}
		return 1;		 
	}
	/* Report section add Entry */	
	public function notesedit($notes,$mynewdate){
		if(!empty($notes)){
		 $count = count($notes);	
		 for($i=0;$i<$count;$i++){			
			$InsertID = DB::table('diary_entries')->insertGetId(
			array('EntryDate' => $mynewdate,
				 'UserId' => session()->get('UserLoginId'),
				 'PredefinedNoteId' => '5',
				 'NoteText' => $notes[$i],
				 'PredefineNoteType'=>'1'						 
				 )
			);
		}
		}
		return 1;
		}
	/* Home section edit Entry */	
	public function homeedit($home,$mynewdate){
		if(!empty($home)){
		 $count = count($home);	
		 for($i=0;$i<$count;$i++){			
			$InsertID = DB::table('diary_entries')->insertGetId(
			array('EntryDate' => $mynewdate,
				 'UserId' => session()->get('UserLoginId'),
				 'PredefinedNoteId' => '11',
				 'NoteText' => $home[$i],
				 'PredefineNoteType'=>'1'						 
				 )
			);
		}
		}
		return 1;
	}
	/* Idea section edit Entry */	
	public function ideaeditfrm($ideaatus,$createiveidea,$EnterId){
		$ideaatus = $ideaatus;
		$createiveidea = $createiveidea;
		// -- creative ideas
		$createiveidea = $createiveidea;
		if(isset($ideaatus)){
			$ideaatus = $ideaatus;
		}else{
		   $ideaatus = array('0','0','0','0','0','0','0','0','0','0');
		}

		if(!empty($createiveidea)){
		 $count = count($createiveidea);	
		 for($i=0;$i<$count;$i++){
			 if(isset($createiveidea[$i])){		
				 count($createiveidea[$i]);
				
				 if(isset($ideaatus[$i])==''){
					 if(count($createiveidea[$i]) > 1){
						 echo 'sd';die;
					for($j=0;$j<count($createiveidea[$i]);$j++){
							$InsertID = DB::table('diary_entry_todos')->insertGetId(
										array('PredefinedNoteId' => '2',
										 'Title' => $createiveidea[$i][$j],
										 'EntryId' => $EnterId,
										 'IsActive' =>  '0',
										 'PredefineType'=>'4'
									)										 
								 );
					}
				}else{
					 $InsertID = DB::table('diary_entry_todos')->insertGetId(
						array('PredefinedNoteId' => '2',
								 'Title' => $createiveidea[$i][0],
								 'EntryId' => $EnterId,
								 'IsActive' =>  '0',
								 'PredefineType'=>'4'	)			 
								 );
				}
				 }else{
					
					 if(count($createiveidea[$i]) > 1){
						
					for($j=0;$j<count($createiveidea[$i]);$j++){
						if(isset($createiveidea[$i][$j])=='1'){
							$check= '1';
						}else{
							$check ='0';
						}
						$InsertID = DB::table('diary_entry_todos')->insertGetId(
						array('PredefinedNoteId' => '2',
								 'Title' => $createiveidea[$i][$j],
								 'EntryId' => $EnterId,
								 'IsActive' =>  $check ,
								 'PredefineType'=>'4'	)			 
								 );
					}
				}else{
					if(isset($createiveidea[$i])=='1'){
							$check= '1';
						}else{
							$check ='0';
						}
					$InsertID = DB::table('diary_entry_todos')->insertGetId(
					  array('PredefinedNoteId' => '2',
						 'Title' => $createiveidea[$i][0],
						 'EntryId' => $EnterId,
						 'IsActive' =>  $check ,
						 'PredefineType'=>'4'	)			 
						 );
				}
				 }
				
			} 
			
		}
		}
	}
	/* Primary simple note section edit Entry */	
	public function primarynoteedit($secondsimpleNotesstatus,$secondsimpleNotes,$EnterId){
		
		$secondsimpleNotesstatus_count = count($secondsimpleNotesstatus);	
		$secondsimpleNotes_count = count($secondsimpleNotes);
		 $EntryRecord = DB::table('diary_entry_todos')
			->where('EntryId',$EnterId)
			->where('PredefineType','5')
			->get();
			
									 
			 if(!empty($EntryRecord)){
				if(isset($EntryRecord[0]->Id)!=""){
					foreach($EntryRecord as $rec){
						$isd[]=$rec->Id;
					}
					
					
					$cou = count($isd);
					for($i=0;$i<13;$i++){
						if(isset($secondsimpleNotesstatus[$i])=='1'){
							$status = '1';
						}else{
							$status = '0';
						}
						DB::table('diary_entry_todos')
						   ->where('Id', $isd[$i])
							  ->update(
							   array( 
									'PredefinedNoteId' => '2',
									'Title' => $secondsimpleNotes[$i][0],
									 'EntryId' => $EnterId,
									 'IsActive' => $status,
									 'PredefineType'=>'5'
									 )
							);
					}
				}else{
					for($i=0;$i<13;$i++){	
						if(isset($secondsimpleNotesstatus[$i])=='1'){
							$status = '1';
						}else{
							$status = '0';
						}						
						$InsertID = DB::table('diary_entry_todos')->insertGetId(
						array('PredefinedNoteId' => '1',
							'PredefinedNoteId' => '2',
									'Title' => $secondsimpleNotes[$i][0],
									 'EntryId' => $EnterId,
									 'IsActive' => $status,
									 'PredefineType'=>'5'					 
							 )
						);
					}
				}
			}  
	 return 1;
		
	}
	/* Idea section add Entry */	
	public function ideaaddfrm($ideaatus,$createiveidea,$EnterId){
		if(isset($createiveidea)!=''){
		  $todotextnews = $createiveidea;
		  $todotextnews_array = array_map('current', $todotextnews);
		}else {
		  $todotextnews = array();	
		}
		if(isset($ideaatus)){
		   $todostatusnews = $ideaatus;
		   $todostatusnewss = array_map('current', $todostatusnews);
		}else{
			$todostatusnews = array();
			$todostatusnewss = array();
			
		}
		 $array = array_map('current', $todotextnews);
		// -- to do list 
		if(!empty($todotextnews_array)){
		 $count = count($todotextnews_array);	
		 for($i=0;$i<$count;$i++){
			 if(isset($todotextnews_array[$i])){		
			if(isset($todostatusnewss[$i])==''){					
					$InsertID = DB::table('diary_entry_todos')->insertGetId(
					array('PredefinedNoteId' => '2',
						 'Title' => $todotextnews_array[$i],
						 'EntryId' => $EnterId,
						 'IsActive' =>  '0',
						 'PredefineType'=>'4'				 
						 )
					);				
				
			}else{					
				$InsertID = DB::table('diary_entry_todos')->insertGetId(
				array('PredefinedNoteId' => '2',
					 'Title' => $todotextnews_array[$i],
					 'EntryId' => $EnterId,
					 'IsActive' =>  $todostatusnewss[$i],
					 'PredefineType'=>'4'				 
					 )
				);
			
			 
			 }
			} 
			
		}
		}
		return 0;
	}
	/* To do section edit Entry */	
	public function todoeditfrm($todostatusnews,$todotextnews,$EnterId){
		$todotextnews_array = $todotextnews;
		$todostatusnews = $todostatusnews;
		if(!empty($todotextnews_array)){
		 $count = count($todotextnews_array);	
		 for($i=0;$i<$count;$i++){
			 if(isset($todotextnews_array[$i])){		
				 count($todotextnews_array[$i]);
				 if(isset($todostatusnews[$i])==''){
					 if(count($todotextnews_array[$i]) > 1){
					for($j=0;$j<count($todotextnews_array[$i]);$j++){
							$InsertID = DB::table('diary_entry_todos')->insertGetId(
										array('PredefinedNoteId' => '2',
										 'Title' => $todotextnews_array[$i][$j],
										 'EntryId' => $EnterId,
										 'IsActive' =>  '0',
										 'PredefineType'=>'3'
									)										 
								);
								 
					}
				}else{
					 $InsertID = DB::table('diary_entry_todos')->insertGetId(
						 array('PredefinedNoteId' => '2',
								 'Title' => $todotextnews_array[$i][0],
								 'EntryId' => $EnterId,
								 'IsActive' =>  '0',
								 'PredefineType'=>'3'	)			 
								 );
				}
				 }else{
					 if(count($todotextnews_array[$i]) > 1){
					for($j=0;$j<count($todotextnews_array[$i]);$j++){
						$InsertID = DB::table('diary_entry_todos')->insertGetId(
						array('PredefinedNoteId' => '2',
								 'Title' => $todotextnews_array[$i][$j],
								 'EntryId' => $EnterId,
								 'IsActive' =>  '1',
								 'PredefineType'=>'3'	)			 
								 );
					}
				}else{
					$InsertID = DB::table('diary_entry_todos')->insertGetId(
					   array('PredefinedNoteId' => '2',
								 'Title' => $todotextnews_array[$i][0],
								 'EntryId' => $EnterId,
								 'IsActive' =>  '1',
								 'PredefineType'=>'3'	)			 
								 );
				}
				 }
				
			} 
			
		}
		}

	}
	/* To do  section add Entry */	
	public function todoaddfrm($todostatusnewsss,$todotextnewsss,$EnterId){
		if(isset($todotextnewsss)!=''){
		  $todotextnews = $todotextnewsss;
		  $todotextnews_array = array_map('current', $todotextnews);
		}else {
		  $todotextnews = array();	
		}
		if(isset($todostatusnewsss)){
		   $todostatusnews = $todostatusnewsss;
		   $todostatusnewss = array_map('current', $todostatusnews);
		}else{
			$todostatusnews = array();
			$todostatusnewss = array();
			
		}
		 $array = array_map('current', $todotextnews);
		// -- to do list 
		if(!empty($todotextnews_array)){
		 $count = count($todotextnews_array);	
		 for($i=0;$i<$count;$i++){
			 if(isset($todotextnews_array[$i])){		
			if(isset($todostatusnewss[$i])==''){					
					$InsertID = DB::table('diary_entry_todos')->insertGetId(
					array('PredefinedNoteId' => '2',
						 'Title' => $todotextnews_array[$i],
						 'EntryId' => $EnterId,
						 'IsActive' =>  '0',
						 'PredefineType'=>'3'				 
						 )
					);				
				
			}else{					
				$InsertID = DB::table('diary_entry_todos')->insertGetId(
				array('PredefinedNoteId' => '2',
					 'Title' => $todotextnews_array[$i],
					 'EntryId' => $EnterId,
					 'IsActive' =>  $todostatusnewss[$i],
					 'PredefineType'=>'3'				 
					 )
				);
			
			 
			 }
			} 
			
		}
		}
		return 0;
	}
	/* Get record by date with parameter */	
	public function getRecordByDateBypara($date){
		 $PredefineDetail = DB::table('diary_entries')
				->whereNull('PredefinedNoteId')	
				->where('EntryDate', $date)				//whereNotNull
				->get();
		return $PredefineDetail;
	 }
	/* Destroyed entry with parameter */
	public function destroyedEntrywithpara($tablename,$para,$value,$par1,$val1){		
		DB::table($tablename)->where($para, $value)->where($par1, $val1)->delete();
		return 1;
	}
	/* Destroyed entry with parameter */
	public function destroyedEntrywithpara1($value){
		DB::table('diary_entry_todos')->where('PredefinedNoteId', '7')->where('EntryId', $value)->delete();				
		return 1;
	}
	 
    
    
    
}
