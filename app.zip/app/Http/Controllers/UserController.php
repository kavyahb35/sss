<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use App\User;

class UserController extends Controller
{
	/* Login page view load */
    public function index(){
		$data['error'] = '';
		return view('user.login',$data);
	}
	
	/* Login code */
	public function login(Request $request){
	
		$data['error'] = '';
		$UserModel = new User();
		$CheckAuthenticate = $UserModel->authentication($request);
		
		if($CheckAuthenticate == '1'){
		     return redirect('create-diary'); 	
		}else{			
		     $data['error'] = 'Unauthenticate credentials.';	
		}
		return view('user.login',$data);
	}
	
	/* Dashboard page */
	public function dashboard(Request $request){
		// echo $request->session()->get('UserLoginName');
		 
		 return view('user.dashboard');
		 //return view('diary.tabdairyentry');
	}
	/* Logout code */
	public function logout(Request $request){		
		session_unset();
		$request->session()->flush();
		$value = $request->session()->forget('UserLoginId');
		$request->session()->forget('UserLoginEmail');
		$request->session()->forget('UserLoginName');
		return redirect('index');
	}
	/* Change password page load */
	public function changePassword(Request $request){
		
	}
}
