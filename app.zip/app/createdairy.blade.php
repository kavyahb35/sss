<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\DiaryEntry;
use App\DiaryEntryTodo;
use DB;
class DiaryEntryController extends Controller
{
	public function index(){
		$DiaryEntryModel = new DiaryEntry();
		$data['DiaryEntry'] = $DiaryEntryModel->getRecordByDate();
        return view('diary.index',$data);
	}
	/* view 7 diary list page load */
    public function create(Request $request){
		
		$currentdatePOST = $request->input('currentdate');
		$UserLoginId = $request->session()->get('UserLoginId');
		$userid = $UserLoginId;
		if($UserLoginId == ''){
			 return redirect('index'); 
		}
		$DiaryEntryModel = new DiaryEntry();
		$data['PrimaryNote'] = $DiaryEntryModel->getRecord('1');
		$data['SecondNote'] = $DiaryEntryModel->getRecord('2');
		$currentDate = date('Y-m-d');
		$lastDate = date("Y-m-d", strtotime("$currentDate -1 day"));
		$secondLastDate = date("Y-m-d", strtotime("$currentDate -2 day")); 
		$thirdLastDate = date("Y-m-d", strtotime("$currentDate -3 day")); 
		$fourLastDate = date("Y-m-d", strtotime("$currentDate -4 day")); 
		$fiveLastDate = date("Y-m-d", strtotime("$currentDate -5 day")); 
		$sixLastDate = date("Y-m-d", strtotime("$currentDate -6 day")); 
$data['SelectedDate'] = '';
$data['primary_habit'] = '';
$data['routine_habit'] = '';
$data['note'] = '';  
			$datepickerDate = $request->input('DairyDate');
			$divDate = $request->input('currentdate');
			$todaydate = date('Y-m-d');
			
			if($datepickerDate!='' && $todaydate!=$datepickerDate){
					 
			 $currentdatePOST = $datepickerDate;
			 
			 /* Left site form data get by date */
		
			$marketing = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'2','PredefineNoteType');			
			if(!empty($marketing)){
				if(isset($marketing[0]->NoteText)!=''){
						$data['market_content'] = $marketing;
					}else{
						$data['market_content'] = '';
					}
			}else{
				$data['market_content'] = '';
			}
			
			$report = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'4','PredefineNoteType');
			if(!empty($report)){
				if(isset($report[0]->NoteText)!=''){
						$data['report_content'] = $report;
					}else{
						$data['report_content'] = '';
					}
			}else{
				$data['report_content'] = '';
			}
			
			$notes = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'5','PredefineNoteType');
			if(!empty($notes)){
				if(isset($notes[0]->NoteText)!=''){
						$data['notes_content'] = $notes;
					}else{
						$data['notes_content'] = '';
					}
			}else{
				$data['notest_content'] = '';
			}
			
			$home = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'11','PredefineNoteType');
			if(!empty($home)){
				if(isset($home[0]->NoteText)!=''){
						$data['home_content'] = $home;
					}else{
						$data['home_content'] = '';
					}
			}else{
				$data['home_content'] = '';
			}
			$res = $DiaryEntryModel->getRecordByDateLimit('diary_entries','EntryDate',$currentdatePOST);
			if(!empty($res)){
				if(isset($res[0]->EntryId)!=''){
					$Entry_ID = $res[0]->EntryId;
					$data['SelectedDate'] = $res[0]->EntryDate;
					$DiaryEntryTodoModel = new DiaryEntryTodo();
					$primary_habit= $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'1');
					
					if(!empty($primary_habit)){
						foreach($primary_habit as $habit){
						  $primary_habitss[] = $habit->PredefinedNoteId;				  
						}	
					}
					if(!empty($primary_habitss)){
						if(isset($primary_habitss)!=''){
								$data['primary_habit'] = $primary_habitss;
							}else{
								$data['primary_habit'] = '';
							}	
					}else{
						 $data['primary_habit'] = array();
					}
					
					$routine_habit = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'2');
					
					if(!empty($routine_habit)){
						foreach($routine_habit as $habit){
						  $routine_habitss[] = $habit->PredefinedNoteId;				  
						}	
					}
					if(!empty($routine_habitss)){
						if(isset($routine_habitss)!=''){
								$data['routine_habit'] = $routine_habitss;
							}else{
								$data['routine_habit'] = '';
							}
					}else{
						 $data['routine_habit'] = array();
					}
					$data['todo'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'3');
					$data['create_idea'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'4');
					$data['second_simple_habit'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'5');
					$data['hates'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'7');
					$data['likes'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'8');			
					$data['thirdNote'] = $DiaryEntryModel->getRecordById('diary_entries','EntryId',$Entry_ID);
				}else{
					$data['SelectedDate'] = '';
					$data['primary_habit'] = array();
					$data['routine_habit'] = array();
				}
			}
			}
			
			
			
			
			
			/* end left form data */
		 
		
			if($divDate!='' ){
					 
			 $currentdatePOST = $request->input('currentdate');
			 
			 /* Left site form data get by date */
		
			$marketing = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'2','PredefineNoteType');			
			if(!empty($marketing)){
				if(isset($marketing[0]->NoteText)!=''){
						$data['market_content'] = $marketing;
					}else{
						$data['market_content'] = '';
					}
			}else{
				$data['market_content'] = '';
			}
			
			$report = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'4','PredefineNoteType');
			if(!empty($report)){
				if(isset($report[0]->NoteText)!=''){
						$data['report_content'] = $report;
					}else{
						$data['report_content'] = '';
					}
			}else{
				$data['report_content'] = '';
			}
			
			$notes = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'5','PredefineNoteType');
			if(!empty($notes)){
				if(isset($notes[0]->NoteText)!=''){
						$data['notes_content'] = $notes;
					}else{
						$data['notes_content'] = '';
					}
			}else{
				$data['notest_content'] = '';
			}
			
			$home = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'11','PredefineNoteType');
			if(!empty($home)){
				if(isset($home[0]->NoteText)!=''){
						$data['home_content'] = $home;
					}else{
						$data['home_content'] = '';
					}
			}else{
				$data['home_content'] = '';
			}
			$res = $DiaryEntryModel->getRecordByDateLimit('diary_entries','EntryDate',$currentdatePOST);
			if(!empty($res)){
				if(isset($res[0]->EntryId)!=''){
					$Entry_ID = $res[0]->EntryId;
					$data['SelectedDate'] = $res[0]->EntryDate;
					$DiaryEntryTodoModel = new DiaryEntryTodo();
					$primary_habit= $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'1');
					
					if(!empty($primary_habit)){
						foreach($primary_habit as $habit){
						  $primary_habitss[] = $habit->PredefinedNoteId;				  
						}	
					}
					if(!empty($primary_habitss)){
						if(isset($primary_habitss)!=''){
								$data['primary_habit'] = $primary_habitss;
							}else{
								$data['primary_habit'] = '';
							}	
					}else{
						 $data['primary_habit'] = array();
					}
					
					$routine_habit = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'2');
					
					if(!empty($routine_habit)){
						foreach($routine_habit as $habit){
						  $routine_habitss[] = $habit->PredefinedNoteId;				  
						}	
					}
					if(!empty($routine_habitss)){
						if(isset($routine_habitss)!=''){
								$data['routine_habit'] = $routine_habitss;
							}else{
								$data['routine_habit'] = '';
							}
					}else{
						 $data['routine_habit'] = array();
					}
					$data['todo'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'3');
					$data['create_idea'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'4');
					$data['second_simple_habit'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'5');
					$data['hates'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'7');
					$data['likes'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'8');			
					$data['thirdNote'] = $DiaryEntryModel->getRecordById('diary_entries','EntryId',$Entry_ID);
				}else{
					$data['SelectedDate'] = '';
					$data['primary_habit'] = array();
					$data['routine_habit'] = array();
				}
			}
			
			
			
			
			
			/* end left form data */
		
		
			}
		
		
		
		/* current date for */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$currentDate);
		
		$var = explode('-',$totalnote_ids);
		$data['simpletotalNotes'] = $var[0];
		$recordId = $var[1];
		if($recordId > 1){
			/* $primary = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId,'PredefineType','1','IsActive','1');
			$second = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId,'PredefineType','2','IsActive','1');
			
			$data['predefinenotetotal'] = $primary + $second;
			$primarytotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','1');
			$secondtotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','2');
			$data['predefinenotetotalstatic'] = $primarytotalnote + $secondtotalnote; */
			
			 $todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId,'PredefineType','3','IsActive','1');
			 $totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$currentDate,'PredefinedNoteId','4');
			/* $idea = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId,'PredefineType','4','IsActive','1');
			$routine = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId,'PredefineType','5','IsActive','1'); */		
			$data['todaytodo'] = $todo;
			$data['totaltodo'] = $totaltodo;
			$data['TotalReport'] = $totalreport;
		}else{
			$data['todaytodo'] ='0';$data['totaltodo'] ='0';$data['TotalReport'] ='0';
		}
		
		/* second day for */
		
		$lastDate_totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$lastDate);
		$var = explode('-',$lastDate_totalnote_ids);
		$data['lastDate_simpletotalNotes'] = $var[0];
		$recordId1 = $var[1];
		if($recordId1 > 1){
			/* $primary = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId1,'PredefineType','1','IsActive','1');
			$second = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId1,'PredefineType','2','IsActive','1');
			$data['lastDate_predefinenotetotal'] = $primary + $second;
			$primarytotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','1');
			$secondtotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','2');
			$data['lastDate_predefinenotetotalstatic'] = $primarytotalnote + $secondtotalnote; */
			
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId1,'PredefineType','3','IsActive','1');
			 $totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId1,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$lastDate,'PredefinedNoteId','4');
			/* $idea = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId1,'PredefineType','4','IsActive','1');
			$routine = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId1,'PredefineType','5','IsActive','1'); */		
			$data['todaytodo1'] = $todo;
			$data['totaltodo1'] = $totaltodo;
			$data['TotalReport1'] = $totalreport;
		}else{
			$data['todaytodo1'] ='0';$data['totaltodo1'] ='0';$data['TotalReport1'] ='0';
		}
		
		/* third nte */
		
		$secondLastDate_totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$secondLastDate);
		$var = explode('-',$secondLastDate_totalnote_ids);
		$data['secondLastDate_simpletotalNotes'] = $var[0];
		$recordId2 = $var[1];
		if($recordId2 > 1){
			/* $primary = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId2,'PredefineType','1','IsActive','1');
			$second = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId2,'PredefineType','2','IsActive','1');
			$data['secondLastDate_predefinenotetotal'] = $primary + $second;
			$primarytotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','1');
			$secondtotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','2');
			$data['secondLastDate_predefinenotetotalstatic'] = $primarytotalnote + $secondtotalnote; */
			
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId2,'PredefineType','3','IsActive','1');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId2,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$secondLastDate,'PredefinedNoteId','4');
			 $data['todaytodo2'] = $todo;
			$data['totaltodo2'] = $totaltodo;
			$data['TotalReport2'] = $totalreport;
			/* $idea = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId2,'PredefineType','4','IsActive','1');
			$routine = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId2,'PredefineType','5','IsActive','1');		
			$data['tsecondLastDate_otalSimplewithstatus'] = $todo+$idea+$routine; */
		}else{
			$data['todaytodo2'] ='0';$data['totaltodo2'] ='0';$data['TotalReport2'] ='0';
		}
		/* fourth  note */
		$thirdLastDate_totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$thirdLastDate);
		$var = explode('-',$thirdLastDate_totalnote_ids);
		$data['thirdLastDate_simpletotalNotes'] = $var[0];
		$recordId3 = $var[1];
		if($recordId3 > 1){
			/* $primary = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId3,'PredefineType','1','IsActive','1');
			$second = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId3,'PredefineType','2','IsActive','1');
			$data['thirdLastDate_predefinenotetotal'] = $primary + $second;
			$primarytotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','1');
			$secondtotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','2');
			$data['thirdLastDate_predefinenotetotalstatic'] = $primarytotalnote + $secondtotalnote; */
			
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId3,'PredefineType','3','IsActive','1');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId3,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$thirdLastDate,'PredefinedNoteId','4');
			 $data['todaytodo3'] = $todo;
			$data['totaltodo3'] = $totaltodo;
			$data['TotalReport3'] = $totalreport;
			/* $idea = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId3,'PredefineType','4','IsActive','1');
			$routine = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId3,'PredefineType','5','IsActive','1');		
			$data['thirdLastDate_totalSimplewithstatus'] = $todo+$idea+$routine; */
		}else{
			$data['todaytodo3'] ='0';$data['totaltodo3'] ='0';$data['TotalReport3'] ='0';
		}
		/* five note */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$fourLastDate);
		$var = explode('-',$totalnote_ids);
		$data['fourLastDate_simpletotalNotes'] = $var[0];
		$recordId4 = $var[1];
		if($recordId4 > 1){
			/* $primary = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId4,'PredefineType','1','IsActive','1');
			$second = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId4,'PredefineType','2','IsActive','1');
			$data['fourLastDate_predefinenotetotal'] = $primary + $second;
			$primarytotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','1');
			$secondtotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','2');
			$data['fourLastDate_predefinenotetotalstatic'] = $primarytotalnote + $secondtotalnote; */
			
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId4,'PredefineType','3','IsActive','1');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId4,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$fourLastDate,'PredefinedNoteId','4');
			 $data['todaytodo4'] = $todo;
			$data['totaltodo4'] = $totaltodo;
			$data['TotalReport4'] = $totalreport;
			/* $idea = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId4,'PredefineType','4','IsActive','1');
			$routine = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId4,'PredefineType','5','IsActive','1');		
			$data['fourLastDate_totalSimplewithstatus'] = $todo+$idea+$routine; */
		}else{
			$data['todaytodo4'] ='0';$data['totaltodo4'] ='0';$data['TotalReport4'] ='0';
		}
		/* Six note */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$fiveLastDate);
		$var = explode('-',$totalnote_ids);
		$data['fiveLastDate_simpletotalNotes'] = $var[0];
		$recordId5 = $var[1];
		if($recordId5 > 1){
			/* $primary = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId5,'PredefineType','1','IsActive','1');
			$second = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId5,'PredefineType','2','IsActive','1');
			$data['fiveLastDate_predefinenotetotal'] = $primary + $second;
			$primarytotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','1');
			$secondtotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','2');
			$data['fiveLastDate_predefinenotetotalstatic'] = $primarytotalnote + $secondtotalnote; */
			
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId5,'PredefineType','3','IsActive','1');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId5,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$fiveLastDate,'PredefinedNoteId','4');
			 $data['todaytodo5'] = $todo;
			$data['totaltodo5'] = $totaltodo;
			$data['TotalReport5'] = $totalreport;
			/* $idea = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId5,'PredefineType','4','IsActive','1');
			$routine = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId5,'PredefineType','5','IsActive','1');		
			$data['fiveLastDate_totalSimplewithstatus'] = $todo+$idea+$routine; */
		}else{
			$data['todaytodo5'] ='0';$data['totaltodo5'] ='0';$data['TotalReport5'] ='0';
		}
		
		/* Seven note */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$sixLastDate);
		$var = explode('-',$totalnote_ids);
		$data['sixLastDate_simpletotalNotes'] = $var[0];
		$recordId6 = $var[1];
		if($recordId6 > 1){
			/* $primary = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId6,'PredefineType','1','IsActive','1');
			$second = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId6,'PredefineType','2','IsActive','1');
			$data['sixLastDate_predefinenotetotal'] = $primary + $second;
			$primarytotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','1');
			$secondtotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','2');
			$data['sixLastDate_predefinenotetotalstatic'] = $primarytotalnote + $secondtotalnote;
			 */
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId6,'PredefineType','1','IsActive','3');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId6,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$sixLastDate,'PredefinedNoteId','4');
			 $data['todaytodo6'] = $todo;
			$data['totaltodo6'] = $totaltodo;
			$data['TotalReport6'] = $totalreport;
			/* $idea = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId6,'PredefineType','1','IsActive','4');
			$routine = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId6,'PredefineType','1','IsActive','5');		
			$data['sixLastDate_totalSimplewithstatus'] = $todo+$idea+$routine; */
				/* end left form data */
			}else{
			$data['todo6'] ='0';$data['totaltodo6'] ='0';$data['TotalReport6'] ='0';
		}
         
		
		
		return view('diary.createdairy',$data);
		
	}
	
	
	
	 public function create_bkup(Request $request){
		
		$currentdatePOST = $request->input('currentdate');
		$UserLoginId = $request->session()->get('UserLoginId');
		$userid = $UserLoginId;
		if($UserLoginId == ''){
			 return redirect('index'); 
		}
		$DiaryEntryModel = new DiaryEntry();
		$data['PrimaryNote'] = $DiaryEntryModel->getRecord('1');
		$data['SecondNote'] = $DiaryEntryModel->getRecord('2');
		$currentDate = date('Y-m-d');
		$lastDate = date("Y-m-d", strtotime("$currentDate -1 day"));
		$secondLastDate = date("Y-m-d", strtotime("$currentDate -2 day")); 
		$thirdLastDate = date("Y-m-d", strtotime("$currentDate -3 day")); 
		$fourLastDate = date("Y-m-d", strtotime("$currentDate -4 day")); 
		$fiveLastDate = date("Y-m-d", strtotime("$currentDate -5 day")); 
		$sixLastDate = date("Y-m-d", strtotime("$currentDate -6 day")); 

		 if($_POST){
			 $currentdatePOST = $request->input('currentdate');
			 
			 /* Left site form data get by date */
		
			$marketing = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'2','PredefineNoteType');			
			if(!empty($marketing)){
				$data['market_content'] = $marketing[0]->NoteText;
			}else{
				$data['market_content'] = '';
			}
			
			$report = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'4','PredefineNoteType');
			if(!empty($report)){
				$data['report_content'] = $report[0]->NoteText;
			}else{
				$data['report_content'] = '';
			}
			
			$notes = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'5','PredefineNoteType');
			if(!empty($notes)){
				$data['notes_content'] = $notes[0]->NoteText;
			}else{
				$data['notest_content'] = '';
			}
			
			$home = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'11','PredefineNoteType');
			if(!empty($home)){
				$data['home_content'] = $home[0]->NoteText;
			}else{
				$data['home_content'] = '';
			}
			$res = $DiaryEntryModel->getRecordByDateLimit('diary_entries','EntryDate',$currentdatePOST);
			$Entry_ID = $res[0]->EntryId;
			$data['SelectedDate'] = $res[0]->EntryDate;
			
			$DiaryEntryTodoModel = new DiaryEntryTodo();
			$primary_habit= $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'1');
			
			if(!empty($primary_habit)){
			    foreach($primary_habit as $habit){
				  $primary_habitss[] = $habit->PredefinedNoteId;				  
				}	
			}
			if(!empty($primary_habitss)){
			    $data['primary_habit'] = $primary_habitss;	
			}else{
			     $data['primary_habit'] = array();
			}
			
			$routine_habit = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'2');
			
			if(!empty($routine_habit)){
			    foreach($routine_habit as $habit){
				  $routine_habitss[] = $habit->PredefinedNoteId;				  
				}	
			}
			if(!empty($routine_habitss)){
			    $data['routine_habit'] = $routine_habitss;	
			}else{
			     $data['routine_habit'] = array();
			}
			$data['todo'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'3');
			$data['create_idea'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'4');
			$data['second_simple_habit'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'5');
			$data['hates'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'7');
			$data['likes'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'8');			
			$data['thirdNote'] = $DiaryEntryModel->getRecordById('diary_entries','EntryId',$Entry_ID);
			
			/* end left form data */
		 }else{
		/* Left site form data get by date */
		
			$marketing = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentDate,$userid,'2','PredefineNoteType');			
			if(!empty($marketing)){
				$data['market_content'] = $marketing[0]->NoteText;
			}else{
				$data['market_content'] = '';
			}
			
			$report = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentDate,$userid,'4','PredefineNoteType');
			if(!empty($report)){
				$data['report_content'] = $report[0]->NoteText;
			}else{
				$data['report_content'] = '';
			}
			
			$notes = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentDate,$userid,'5','PredefineNoteType');
			if(!empty($notes)){
				$data['notes_content'] = $notes[0]->NoteText;
			}else{
				$data['notest_content'] = '';
			}
			
			$home = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentDate,$userid,'11','PredefineNoteType');
			if(!empty($home)){
				$data['home_content'] = $home[0]->NoteText;
			}else{
				$data['home_content'] = '';
			}
			$res = $DiaryEntryModel->getRecordByDateLimit('diary_entries','EntryDate',$currentDate);
			$Entry_ID = $res[0]->EntryId;
			$data['SelectedDate'] = $res[0]->EntryDate;
			$DiaryEntryTodoModel = new DiaryEntryTodo();
			$primary_habit= $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'1');
			
			if(!empty($primary_habit)){
			    foreach($primary_habit as $habit){
				  $primary_habitss[] = $habit->PredefinedNoteId;				  
				}	
			}
			if(!empty($primary_habitss)){
			    $data['primary_habit'] = $primary_habitss;	
			}else{
			     $data['primary_habit'] = array();
			}
			
			$routine_habit = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'2');
			
			if(!empty($routine_habit)){
			    foreach($routine_habit as $habit){
				  $routine_habitss[] = $habit->PredefinedNoteId;				  
				}	
			}
			if(!empty($routine_habitss)){
			    $data['routine_habit'] = $routine_habitss;	
			}else{
			     $data['routine_habit'] = array();
			}
			$data['todo'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'3');
			$data['create_idea'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'4');
			$data['second_simple_habit'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'5');
			$data['hates'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'7');
			$data['likes'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'8');			
			$data['thirdNote'] = $DiaryEntryModel->getRecordById('diary_entries','EntryId',$Entry_ID);
			
			/* end left form data */
         }

		/* current date for */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$currentDate);
		$var = explode('-',$totalnote_ids);
		$data['simpletotalNotes'] = $var[0];
		$recordId = $var[1];
		
		$primary = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId,'PredefineType','1','IsActive','1');
		$second = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId,'PredefineType','2','IsActive','1');
		
		$data['predefinenotetotal'] = $primary + $second;
		$primarytotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','1');
		$secondtotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','2');
		$data['predefinenotetotalstatic'] = $primarytotalnote + $secondtotalnote;
		
		$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId,'PredefineType','3','IsActive','1');
		$idea = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId,'PredefineType','4','IsActive','1');
		$routine = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId,'PredefineType','5','IsActive','1');		
		$data['totalSimplewithstatus'] = $todo+$idea+$routine;
		
		/* second day for */
		
		$lastDate_totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$lastDate);
		$var = explode('-',$lastDate_totalnote_ids);
		$data['lastDate_simpletotalNotes'] = $var[0];
		$recordId1 = $var[1];
		
		$primary = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId1,'PredefineType','1','IsActive','1');
		$second = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId1,'PredefineType','2','IsActive','1');
		$data['lastDate_predefinenotetotal'] = $primary + $second;
		$primarytotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','1');
		$secondtotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','2');
		$data['lastDate_predefinenotetotalstatic'] = $primarytotalnote + $secondtotalnote;
		
		$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId1,'PredefineType','3','IsActive','1');
		$idea = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId1,'PredefineType','4','IsActive','1');
		$routine = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId1,'PredefineType','5','IsActive','1');		
		$data['lastDate_totalSimplewithstatus'] = $todo+$idea+$routine;
		
		/* third nte */
		
		$secondLastDate_totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$secondLastDate);
		$var = explode('-',$secondLastDate_totalnote_ids);
		$data['secondLastDate_simpletotalNotes'] = $var[0];
		$recordId2 = $var[1];
		
		$primary = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId2,'PredefineType','1','IsActive','1');
		$second = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId2,'PredefineType','2','IsActive','1');
		$data['secondLastDate_predefinenotetotal'] = $primary + $second;
		$primarytotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','1');
		$secondtotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','2');
		$data['secondLastDate_predefinenotetotalstatic'] = $primarytotalnote + $secondtotalnote;
		
		$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId2,'PredefineType','3','IsActive','1');
		$idea = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId2,'PredefineType','4','IsActive','1');
		$routine = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId2,'PredefineType','5','IsActive','1');		
		$data['tsecondLastDate_otalSimplewithstatus'] = $todo+$idea+$routine;
		
		/* fourth  note */
		$thirdLastDate_totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$thirdLastDate);
		$var = explode('-',$thirdLastDate_totalnote_ids);
		$data['thirdLastDate_simpletotalNotes'] = $var[0];
		$recordId3 = $var[1];
		
		$primary = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId3,'PredefineType','1','IsActive','1');
		$second = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId3,'PredefineType','2','IsActive','1');
		$data['thirdLastDate_predefinenotetotal'] = $primary + $second;
		$primarytotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','1');
		$secondtotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','2');
		$data['thirdLastDate_predefinenotetotalstatic'] = $primarytotalnote + $secondtotalnote;
		
		$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId3,'PredefineType','3','IsActive','1');
		$idea = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId3,'PredefineType','4','IsActive','1');
		$routine = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId3,'PredefineType','5','IsActive','1');		
		$data['thirdLastDate_totalSimplewithstatus'] = $todo+$idea+$routine;
		
		/* five note */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$fourLastDate);
		$var = explode('-',$totalnote_ids);
		$data['fourLastDate_simpletotalNotes'] = $var[0];
		$recordId4 = $var[1];
		
		$primary = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId4,'PredefineType','1','IsActive','1');
		$second = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId4,'PredefineType','2','IsActive','1');
		$data['fourLastDate_predefinenotetotal'] = $primary + $second;
		$primarytotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','1');
		$secondtotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','2');
		$data['fourLastDate_predefinenotetotalstatic'] = $primarytotalnote + $secondtotalnote;
		
		$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId4,'PredefineType','3','IsActive','1');
		$idea = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId4,'PredefineType','4','IsActive','1');
		$routine = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId4,'PredefineType','5','IsActive','1');		
		$data['fourLastDate_totalSimplewithstatus'] = $todo+$idea+$routine;
		
		/* Six note */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$fiveLastDate);
		$var = explode('-',$totalnote_ids);
		$data['fiveLastDate_simpletotalNotes'] = $var[0];
		$recordId5 = $var[1];
		
		$primary = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId5,'PredefineType','1','IsActive','1');
		$second = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId5,'PredefineType','2','IsActive','1');
		$data['fiveLastDate_predefinenotetotal'] = $primary + $second;
		$primarytotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','1');
		$secondtotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','2');
		$data['fiveLastDate_predefinenotetotalstatic'] = $primarytotalnote + $secondtotalnote;
		
		$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId5,'PredefineType','3','IsActive','1');
		$idea = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId5,'PredefineType','4','IsActive','1');
		$routine = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId5,'PredefineType','5','IsActive','1');		
		$data['fiveLastDate_totalSimplewithstatus'] = $todo+$idea+$routine;
		
		
		/* Seven note */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$sixLastDate);
		$var = explode('-',$totalnote_ids);
		$data['sixLastDate_simpletotalNotes'] = $var[0];
		$recordId6 = $var[1];
		
		$primary = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId6,'PredefineType','1','IsActive','1');
		$second = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId6,'PredefineType','2','IsActive','1');
		$data['sixLastDate_predefinenotetotal'] = $primary + $second;
		$primarytotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','1');
		$secondtotalnote = $DiaryEntryModel->CountSimpleNotesWithStatus('predefined_notes','NoteTypeId','4','IsActive','1','PredefinedNoteType','2');
		$data['sixLastDate_predefinenotetotalstatic'] = $primarytotalnote + $secondtotalnote;
		
		$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId6,'PredefineType','1','IsActive','3');
		$idea = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId6,'PredefineType','1','IsActive','4');
		$routine = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId6,'PredefineType','1','IsActive','5');		
		$data['sixLastDate_totalSimplewithstatus'] = $todo+$idea+$routine;
		
		
		
		
		return view('diary.createdairy',$data);
		
	}
	/* Insert to store new date in diary entry */
	public function store(Request $request){
		
		$UserId = $request->session()->get('UserLoginId');
		$EntryDate = $request->input('EntryDate');
		$dairyEntry = $this->validate(request(), [
		  'EntryDate' => 'required',
		]);
		if(!empty($dairyEntry)){
			$DiaryEntryModel = new DiaryEntry();
			$Insertrow = $DiaryEntryModel->store($dairyEntry);
			if($Insertrow!='0' && $Insertrow!='' ){
				return redirect('dairy-entry/'.$Insertrow);
				return back()->with('success', 'Diary Entry has been added');
			}else{
				return back()->with('error', 'Diary Entry has been already generated');
			}
		}		
		return back()->with('error', 'Diary Entry has been generate some problem');
	}
	/* create diary entry page load */
	public function edit(Request $request,$id){		
		$DiaryEntryModel = new DiaryEntry();
		$data['PrimaryNote'] = $DiaryEntryModel->getRecord('1');
		$data['SecondNote'] = $DiaryEntryModel->getRecord('2');
		$data['thirdNote'] = $DiaryEntryModel->getRecordById('diary_entries','EntryId',$id);
		return view('diary.updatecreatedairy',$data);
		//return view('diary.tabdairyentry',$data);
		//return view('diary.dairyentry',$data);
	}
	/* create new diary entry */
	public function update(Request $request,$id){
		
		$DiaryEntryModel = new DiaryEntry();
		$added = $DiaryEntryModel->added($_POST);
		if($added=='1' ){
				//return redirect('dairy');
				return redirect('create-diary');
				
				return back()->with('success', 'Diary Entry has been added');
			}else{
				return back()->with('error', 'Diary Entry has been generate some problem');
			}
		
	}
	/* Get Dairy Entry page load */
	public function getDairy(Request $request,$date){
		$DiaryEntryModel = new DiaryEntry();
		$data['SelectedDate'] = $date;
		$userid = $request->session()->get('UserLoginId');
		$marketing = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$date,$userid,'2','PredefineNoteType');			
		if(!empty($marketing)){
			if(isset($marketing[0]->NoteText)!=''){
				$data['market_content'] = $marketing;
			}else{
				$data['market_content'] = '';
			}
		}else{
			$data['market_content'] = '';
		}
		
		$report = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$date,$userid,'4','PredefineNoteType');
		if(!empty($report)){
			if(isset($report[0]->NoteText)!=''){
				$data['report_content'] = $report;
			}else{
				$data['report_content'] = '';
			}
		}else{
			$data['report_content'] = '';
		}
		
		$notes = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$date,$userid,'5','PredefineNoteType');
		if(!empty($notes)){
			if(isset($notes[0]->NoteText)!=''){
				$data['notes_content'] = $notes;
			}else{
				$data['notes_content'] = '';
			}
		}else{
			$data['notest_content'] = '';
		}
		
		$home = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$date,$userid,'11','PredefineNoteType');
		if(!empty($home)){
			if(isset($home[0]->NoteText)!=''){
				$data['home_content'] = $home;
			}else{
				$data['home_content'] = '';
			}
		}else{
			$data['home_content'] = '';
		}
		
		$res = $DiaryEntryModel->getRecordByDateLimit('diary_entries','EntryDate',$date);		
		if(!empty($res)){
			if(isset($res[0]->EntryId)!=''){
				$Entry_ID = $res[0]->EntryId;
				$DiaryEntryTodoModel = new DiaryEntryTodo();
				$primary_habit= $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'1');
				
				if(!empty($primary_habit)){
					foreach($primary_habit as $habit){
					  $primary_habitss[] = $habit->PredefinedNoteId;				  
					}	
				}
				if(!empty($primary_habitss)){
					if(isset($primary_habitss)!=''){
						$data['primary_habit'] = $primary_habitss;
					}else{
						$data['primary_habit'] = '';
					}	
				}else{
					 $data['primary_habit'] = array();
				}
				
				$routine_habit = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'2');
				
				if(!empty($routine_habit)){
					foreach($routine_habit as $habit){
					  $routine_habitss[] = $habit->PredefinedNoteId;				  
					}	
				}
				if(!empty($routine_habitss)){
					if(isset($routine_habitss)!=''){
						$data['routine_habit'] = $routine_habitss;
					}else{
						$data['routine_habit'] = '';
					}
				}else{
					 $data['routine_habit'] = array();
				}
				
				$data['todo'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'3');
				$data['create_idea'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'4');
				$data['second_simple_habit'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'5');
				$data['hates'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'7');
				$data['likes'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'8');
				
				
				$data['PrimaryNote'] = $DiaryEntryModel->getRecord('1');
				$data['SecondNote'] = $DiaryEntryModel->getRecord('2');
				$data['thirdNote'] = $DiaryEntryModel->getRecordById('diary_entries','EntryId',$Entry_ID);	
			}else{
				$data['routine_habit'] = array();
				 $data['primary_habit'] = array();
			}
		}
		
		
		return view('diary.editdairyentry',$data);
		//return view('diary.tabeditdairyentry',$data);
		//return view('diary.editdairyentry',$data);
			
	}
	/* Edit data entry */
	public function updateEntry(Request $request,$date){
		  //  echo '<pre>';print_r($_POST);die;
			$DiaryEntryModel = new DiaryEntry();
			$result = $DiaryEntryModel->getRecordByDateLimit('diary_entries','EntryDate',$date);
			$Entry_ID = $result[0]->EntryId;
			
			
			$DiaryEntryTodoModel = new DiaryEntryTodo();
			$destroy = $DiaryEntryTodoModel->destroyId($Entry_ID);
			$destroyEntry = $DiaryEntryTodoModel->destroyedEntry($date);
			if($destroy == '1' && $destroyEntry =='1'){
				$added = $DiaryEntryModel->edited($_POST);
				return redirect('create-diary');
			}
			return redirect('create-diary');
			
	}
	/* Delete diary entry */
	public function deleteEntry(Request $request,$id){
		   $DiaryEntryModel = new DiaryEntry();
			$result = $DiaryEntryModel->getRecordByDateLimit('diary_entries','EntryId',$id);
			$Entry_Date = $result[0]->EntryDate;
			
			$DiaryEntryModel->destroyedEntry('diary_entries','EntryDate',$Entry_Date);
			$DiaryEntryModel->destroyedEntry('diary_entry_todos','EntryId',$id);
			echo json_encode('1');
	}
	
	/* View Diary Entry page load */
	public function viewDiaryEntry(Request $request){		
		$DairyDate = $request->input('DairyDate');
		$DiaryEntryModel = new DiaryEntry();
		$userId = session()->get('UserLoginId');
	    $Date = date('Y-m-d');
		$checkRecord = $DiaryEntryModel->getRecordByDateLimit('diary_entries','EntryDate',$DairyDate);
		if($DairyDate!=''){
			if(!empty($checkRecord)){
				if(isset($checkRecord[0]->EntryId)!=''){
					return redirect('dairy/'.$DairyDate.'/get');
				}else{
					$EntryRecord = DB::table('diary_entries')
					->where('EntryDate',$DairyDate)
					->where('UserId',$userId)
					->get();
					if(!empty($EntryRecord)){
						if(isset($EntryRecord[0]->EntryId)!=''){
							return 0;
						}else{
							$InsertID = DB::table('diary_entries')->insertGetId(
							array('EntryDate' => $DairyDate,
								 'UserId' => $userId,
								 'created_at' => $Date,
								 
								 )
						);
						return redirect('dairy-entry/'.$InsertID);
						}
						
					}
				}
			}else{
				$EntryRecord = DB::table('diary_entries')
				->where('EntryDate',$DairyDate)
				->where('UserId',$userId)
				->get();
				if(!empty($EntryRecord)){
					if(isset($EntryRecord[0]->EntryId)!=''){
						return 0;
					}else{
						$InsertID = DB::table('diary_entries')->insertGetId(
						array('EntryDate' => $DairyDate,
							 'UserId' => $userId,
							 'created_at' => $Date,
							 
							 )
					);
					return redirect('dairy-entry/'.$InsertID);
					
					}
					
				}
			}
		}else{
			return back()->with('error', 'Please select date from calender');
		}
		
	}
	
	/* View Diary entry */
	public function viewEntry(Request $request,$id){
		echo $id;
	}
}
