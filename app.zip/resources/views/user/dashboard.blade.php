@extends('layout.inner')
@section('content')
<!--<div style="width:20%;float:right;text-align: right;">
   <a href="{{ url('create-diary') }}" class="btn btn-primary"> Create New Note </a>
</div>-->
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
   <h1 class="h2">Dashboard</h1>
   <div class="btn-toolbar mb-2 mb-md-0">
      <div class="btn-group">
         <button type="button" class="btn btn-sm btn-outline-secondary btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         <span data-feather="calendar"></span>
         This week
         </button>
         <div class="dropdown-menu dropdown-menu-right">
            <button class="dropdown-item" type="button">Last Week</button>
            <button class="dropdown-item" type="button">This Month</button>
            <button class="dropdown-item" type="button">Last Month</button>
         </div>
      </div>
   </div>
</div>
<style>
  .bg-dark1{  margin-top: 50%; }
</style>
@include('include.footer')
<!--<canvas class="my-4" id="myChart" width="900" height="380"></canvas>-->

@endsection