<link href="{{ asset('/public/assets/css/menu.css') }}" rel="stylesheet">
 <div class="nav-side-menu">
    <div class="brand">Cuiek Diary </div>
    <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
  
        <div class="menu-list">
  
            <ul id="menu-content"  class="menu-content collapse out">
                
				 <li @if(Request::url()== url('dashboard')) class="collapsed active" @else class="collapsed " @endif>
                  <a href="{{ url('dashboard')}}">
                  <i class="fa fa-dashboard fa-lg"></i> Dashboard
                  </a>
                </li>
				<li @if(Request::url()== url('create-diary')) class="collapsed active" @else class="collapsed" @endif>
                  <a href="{{ url('create-diary')}}">
                  <i class="fa fa-sticky-note-o"></i> Diary
                  </a>
                </li>

                <li data-toggle="collapse" data-target="#service" @if(Request::url()== url('plan')) class="collapsed active" @else class="collapsed" @endif>
                  <a href=""><i class="fa fa-check-square-o"></i> Plan <span class="arrow"></span></a>
                </li>  
                <ul class="sub-menu collapse" id="service">
                  <li><a href="{{ url('plan') }}">Topic</a></li>
                  <li><a href="{{ url('plan') }}">Notes under topic </a></li>
                </ul>


                <li data-toggle="collapse" data-target="#new" @if(Request::url()== url('goal')) class="collapsed active" @else class="collapsed" @endif>
                  <a href="{{ url('goal') }}"><i class="fa fa-bullseye"></i> Goal <span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="new">
                 <li><a href="{{ url('goal') }}">One note with due date </a> </li>
                </ul>

            </ul>
     </div>
</div>