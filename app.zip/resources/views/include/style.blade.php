 <!-- STYLESHEETS -->
        <style type="text/css">
            [fuse-cloak],
            .fuse-cloak {
                display: none !important;
            }
        </style>
		
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- Icons.css -->
    <link type="text/css" rel="stylesheet" href="{{ url('public/') }}/assets/css/main.css">
    <!-- Cueik CSS -->
    <link type="text/css" rel="stylesheet" href="{{ url('public/') }}/assets/css/cueik.css">
    <!-- / STYLESHEETS -->
