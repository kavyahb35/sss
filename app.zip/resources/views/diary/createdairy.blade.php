@extends('layout.inner')
@section('content')
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
   <h1 class="h2">Daily Diary </h1>
   <span style="">
      <form  method="post" name="addeditform" id="addeditform" action="{{ url('edit-create-diary') }}" >
         {{csrf_field()}}
         <div class='input-group date' id='EntryDate'>
            <input type='text' class="form-control" name="DairyDate" id="datepicker" readonly value="@php 
               $currentDate = date('Y-m-d'); @endphp {{ $currentDate}}" onchange="submitfrommy()" />
         </div>
      </form>
   </span>
   <script>
      function submitfrommy(){      
      var v = $("#datepicker").val();
      var cdate = "@php echo $currentDate = date('Y-m-d') @endphp";
      var dairy = v.trim();
      var curdate = cdate.trim();

      if(dairy==curdate){
		  document.getElementById("addeditform").submit(); 
      }else{
         document.getElementById("addeditform").submit(); 
      }
      
      } 
   </script>
</div>
<div class="row">
   <div class="col-md-4 col-sm-12 col-xs-12 col-lg-3 order-md-2 mb-3">
      <h4 class="d-flex justify-content-between align-items-center mb-3">
         <span class="text-muted">Last 7 Days</span>
      </h4>
      @php 
        $currentDate = date('Y-m-d');                  
        $dayName = date('l', strtotime($currentDate));
        $lastDate = date("Y-m-d", strtotime("$currentDate -1 day")); 
        $lastDayName = date('l', strtotime($lastDate));
        $secondLastDate = date("Y-m-d", strtotime("$currentDate -2 day")); 
        $secondDayName = date('l', strtotime($secondLastDate));
        $thirdLastDate = date("Y-m-d", strtotime("$currentDate -3 day")); 
        $thirdDayName = date('l', strtotime($thirdLastDate));
        $fourLastDate = date("Y-m-d", strtotime("$currentDate -4 day")); 
        $fourDayName = date('l', strtotime($fourLastDate));
        $fiveLastDate = date("Y-m-d", strtotime("$currentDate -5 day")); 
        $fiveDayName = date('l', strtotime($fiveLastDate));
        $sixLastDate = date("Y-m-d", strtotime("$currentDate -6 day")); 
        $sixDayName = date('l', strtotime($sixLastDate));
        $secondLastDate1 =  date('j M', strtotime($secondLastDate));
        $thirdLastDate1 =  date('j M', strtotime($thirdLastDate));
        $fourLastDate1 =  date('j M', strtotime($fourLastDate));
        $fiveLastDate1 =  date('j M', strtotime($fiveLastDate));
        $sixLastDate1 =  date('j M', strtotime($sixLastDate));
      @endphp
      <form method="post" action="{{ url('create-diary') }}" name="postform" id="postform">
         <ul class="list-group mb-3">
            {{csrf_field()}}
            <li class="list-group-item d-flex justify-content-between bg-light " @if ($currentDate==$SelectedDate) id="bgcolor" @endif >
            <a onclick="demo('<?php echo $currentDate ?>')" >
               <div @if ($currentDate==$SelectedDate) class="text-selected" @endif>
               <h6 class="my-0"><input type="hidden" name="currentdate1" id="currentid" value="{{ $currentDate }}"    > Today </h6>
               <small class="text-muted">To do : {{ $todaytodo.'/' .$totaltodo }}  </small><br>
               <small class="text-muted">Report to check  : {{ $TotalReport.'/' .$TotalReport }}  </small><br>
               </div>
            </a>
         </li>
         <li class="list-group-item d-flex justify-content-between lh-condensed" @if ($lastDate==$SelectedDate) id="bgcolor" @endif>
            <a onclick="demo('<?php echo  $lastDate ?>')" >
               <div @if ($lastDate==$SelectedDate) class="text-selected" @endif>
               <h6 class="my-0">    <input type="hidden" name="currentdate2" id="currentid" value="{{ $lastDate }}"  {{ $lastDate == $SelectedDate ? 'checked' : '' }} > Yesterday</h6>
               <small class="text-muted">To do : {{ $todaytodo1.'/' .$totaltodo1 }}  </small><br>
               <small class="text-muted">Report to check  : {{ $TotalReport1.'/' .$TotalReport1 }}  </small><br>
               </div>
            </a>
         </li>
         <li class="list-group-item d-flex justify-content-between lh-condensed" @if ($secondLastDate==$SelectedDate) id="bgcolor" @endif>
            <a onclick="demo('<?php echo  $secondLastDate ?>')" >
               <div @if ($secondLastDate==$SelectedDate) class="text-selected" @endif>
               <h6 class="my-0"><input type="hidden" name="currentdate3" id="currentid" value="{{ $secondLastDate }}"  {{ $secondLastDate == $SelectedDate ? 'checked' : '' }}>  {{  $secondDayName .' - '.$secondLastDate1  }}</h6>
               <small class="text-muted">To do : {{ $todaytodo2.'/' .$totaltodo2 }}  </small><br>
               <small class="text-muted">Report to check  : {{ $TotalReport2.'/' .$TotalReport2 }}  </small><br>
               </div>
            </a>
         </li>
         <li class="list-group-item d-flex justify-content-between lh-condensed" @if ($thirdLastDate==$SelectedDate) id="bgcolor" @endif>
            <a onclick="demo('<?php echo  $thirdLastDate ?>')" >
               <div @if ($thirdLastDate==$SelectedDate) class="text-selected" @endif>
               <h6 class="my-0"><input type="hidden" name="currentdate4" id="currentid" value="{{ $thirdLastDate }}"  {{ $thirdLastDate == $SelectedDate ? 'checked' : '' }}>  {{  $thirdDayName.' - '.$thirdLastDate1  }}</h6>
               <small class="text-muted">To do : {{ $todaytodo3.'/' .$totaltodo3 }}  </small><br>
               <small class="text-muted">Report to check  : {{ $TotalReport3.'/' .$TotalReport3 }}  </small><br>
               </div>
            </a>
         </li>
         <li class="list-group-item d-flex justify-content-between lh-condensed" @if ($fourLastDate==$SelectedDate) id="bgcolor" @endif>
            <a onclick="demo('<?php echo  $fourLastDate ?>')" >
               <div @if ($fourLastDate==$SelectedDate) class="text-selected" @endif>
               <h6 class="my-0"><input type="hidden" name="currentdate5" id="currentid" value="{{ $fourLastDate }}"   {{ $fourLastDate == $SelectedDate ? 'checked' : '' }}> {{ $fourDayName.' - '.$fourLastDate1 }}</h6>
               <small class="text-muted">To do : {{ $todaytodo4.'/' .$totaltodo4 }}  </small><br>
               <small class="text-muted">Report to check  : {{ $TotalReport4.'/' .$TotalReport4 }}  </small><br>
               </div>
            </a>
         </li>
         <li class="list-group-item d-flex justify-content-between lh-condensed" @if ($fiveLastDate==$SelectedDate) id="bgcolor" @endif>
            <a onclick="demo('<?php echo  $fiveLastDate ?>')" >
               <div @if ($fiveLastDate==$SelectedDate) class="text-selected" @endif>
               <h6 class="my-0"><input type="hidden" name="currentdate6" id="currentid" value="{{ $fiveLastDate }}"  {{ $fiveLastDate == $SelectedDate ? 'checked' : '' }}> {{ $fiveDayName.' - '.$fiveLastDate1 }}</h6>
               <small class="text-muted">To do : {{ $todaytodo5.'/' .$totaltodo5 }}  </small><br>
               <small class="text-muted">Report to check  : {{ $TotalReport5.'/' .$TotalReport5 }}  </small><br>
               </div>
            </a>
         </li>
         <li class="list-group-item d-flex justify-content-between lh-condensed" @if ($sixLastDate==$SelectedDate) id="bgcolor" @endif>
            <a onclick="demo('<?php echo  $sixLastDate ?>')" >
               <div @if ($sixLastDate==$SelectedDate) class="text-selected" @endif>
               <h6 class="my-0"><input type="hidden" name="currentdate7" id="currentid" value="{{ $sixLastDate }}"  {{ $sixLastDate == $SelectedDate ? 'checked' : '' }}> {{ $sixDayName.' - '.$sixLastDate1 }}</h6>
               <small class="text-muted">To do : {{ $todaytodo6.'/' .$totaltodo6 }}  </small><br>
               <small class="text-muted">Report to check  : {{ $TotalReport6.'/' .$TotalReport6 }}  </small><br>
               </div>
            </a>
         </li>
      </ul><div id="selecteddatehabit"></div>
   </form>
      @if ($errors->any())
      <div class="alert alert-danger">
         <ul>
           @foreach ($errors->all() as $error)
           <li>{{ $error }}</li>
           @endforeach
         </ul>
      </div>
      <br />
      @endif
      @if (\Session::has('success'))
      <div class="alert alert-success">
         <p>{{ \Session::get('success') }}</p>
      </div>
      <br />
      @endif
      @if (\Session::has('error'))
      <div class="alert alert-danger">
         <p>{{ \Session::get('error') }}</p>
      </div>
      <br />
      @endif
      </div>
<!------ Include the above in your HEAD tag ---------->
   <style>
      .btn span.glyphicon {            
      opacity: 0;          
      }
      .btn.active span.glyphicon {           
      opacity: 1;          
      }
   </style>
 <div class="col-md-8 col-sm-12 col-xs-12 col-lg-9 order-md-1">
   <div class="current-div">
      <form class="needs-validation" novalidate>
         <div class="row">
            <div class="col-md-12 mb-3 col-sm-12 col-xs-12 col-lg-8 >
               <div class="panel panel-default">
               <div class="panel-heading pol1">
                  Wellness Habits <!--<strike>--> 
                  <a class="right-align" data-toggle="modal" href="#wellnesshabits"><i class="fa fa-edit"></i></a>
               </div>
               <div class="panel-body">
                  <div class="box">
                     @if (!empty($PrimaryNote))
                     @foreach ($PrimaryNote as $note)
                     <div class="inbox">
                        <span class="btn-group" data-toggle="buttons">
                        <label class="btn btnnp btn-success @if(in_array($note->id,$primary_habit)) active @endif ">
                        <input type="checkbox" autocomplete="off" @if(in_array($note->id,$primary_habit)) checked @endif>
                        @if(in_array($note->id,$primary_habit))<i class="fa fa-check"></i> @else <i class="f1 btnnp"></i> @endif 
                        </label>
                        </span>
                       @if(in_array($note->id,$primary_habit)) <strike> {{  $note->NoteText }} </strike> @else {{  $note->NoteText }} @endif 
                     </div>
                     @endforeach
                     @else
                     <p class="pcls" style="text-align:center"> No Result Found</p>
                     @endif
                  </div>
               </div>
            </div>
            <div class="col-md-12 col-sm-12 col-xs-12 col-lg-4  mb-3">
               <div class="panel panel-default">
                  <div class="panel-heading">Marketing 
                     @if(!empty($market_content))
                     @if($market_content[0]->NoteText!='')                       
                     <a class="right-align" data-toggle="modal" href="#market-edit"><i class="fa fa-edit"></i></a>
                     <a class="right-align" data-toggle="modal" href="#market-add"><i class="fa fa-plus"></i></a>
                     @endif @else
                     <a class="right-align" data-toggle="modal" href="#market-add"><i class="fa fa-plus"></i></a>
                     @endif      
                  </div>
                  <div class="panel-body">
                     <div class="box">
                        @if(!empty($market_content))
                        @foreach($market_content as $market)
                        @if($market->NoteText!='')
                        <p class="pcls">{{ $market->NoteText}}</p>
                        @endif
                        @endforeach
                        @else
                        <p class="pcls" style="text-align:center"> No Result Found</p>
                        @endif
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="panel panel-default">
            <div class="panel-heading">To Do List 
               @if(!empty($todo))
               @if(isset($todo[0]->Title)!='')
               <a class="right-align" data-toggle="modal" href="#todo-edit"><i class="fa fa-edit"></i></a> 
               <a class="right-align" data-toggle="modal" href="#todo-add"><i class="fa fa-plus"></i></a>
               @else 
               <a class="right-align" data-toggle="modal" href="#todo-add"><i class="fa fa-plus"></i></a>
               @endif
               @else 
               <a class="right-align" data-toggle="modal" href="#todo-add"><i class="fa fa-plus"></i></a>
               @endif
            </div>
            <div class="panel-body">
               <div class="box">
                  <div class="row">
                     @if(!empty($todo)) @php $i = 0 @endphp
                     @foreach($todo as $todolist)
                     <div class="col-md-1 kl1">
                        <span class="btn-group" data-toggle="buttons">
                        <label class="btn btn-success @if($todolist->IsActive) active @endif ">
                        <input type="checkbox" autocomplete="off" name="todostatusnews[0][]" value="1" @if($todolist->IsActive) checked @endif>
                        @if($todolist->IsActive)<i class="fa fa-check"></i> @else <i class="f1"></i> @endif 
                        </label>
                        </span>
                     </div>
                     <div class="col-md-10 col-lg-11 mb-3">
                        <input type="text" name="todotextnews[0][]"  class="form-control" value="{{ $todolist->Title }}">                
                     </div>
                     @php $i++ @endphp
                     @endforeach
                     @else
                     <p class="pcls" style="text-align:center"> No Result Found</p>
                     @endif
                  </div>
                  <div id="Content"></div>
               </div>
            </div>
         </div>
         <br>
         <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12 col-lg-6  mb-3">
               <div class="panel panel-default">
                  <div class="panel-heading">Reports 
                     @if(!empty($report_content))
                     @if(isset($report_content[0]->NoteText)!='')
                     <a class="right-align" data-toggle="modal" href="#report-edit"><i class="fa fa-edit"></i></a> 
                     <a class="right-align" data-toggle="modal" href="#report-add"><i class="fa fa-plus"></i></a>
                     @else
                     <a class="right-align" data-toggle="modal" href="#report-add"><i class="fa fa-plus"></i></a>
                     @endif
                     @else
                     <a class="right-align" data-toggle="modal" href="#report-add"><i class="fa fa-plus"></i></a>
                     @endif
                  </div>
                  <div class="panel-body">
                     <div class="box">
                        @if(!empty($report_content))
                        @foreach($report_content as $report)
                        @if($report->NoteText!='')
                        <p class="pcls">{{ $report->NoteText}}</p>
                        @endif   
                        @endforeach
                        @else
                        <p class="pcls" style="text-align:center"> No Result Found</p>
                        @endif
                     </div>
                  </div>
               </div>
               <br>
               <div class="border-box">
                  <div class="panel panel-default">
                     <div class="panel-heading">Daily Routine Habits 
                        @if (!empty($second_simple_habit))
                        @if(isset($second_simple_habit[0]->Title) !='')
                        <a class="right-align" data-toggle="modal" href="#routine-habit-add"><i class="fa fa-edit" ></i></a>
                        <a class="right-align" data-toggle="modal" href="#routine-habit-add"><i class="fa fa-plus" ></i></a>
                        @else             
                        <a class="right-align" data-toggle="modal" href="#routine-habit-add"><i class="fa fa-plus"></i></a> 
                        @endif
                        @else             
                        <a class="right-align" data-toggle="modal" href="#routine-habit-add"><i class="fa fa-plus" ></i></a>
                        @endif
                     </div>
                     <div class="panel-body">
                        <div class="row">
                           <div class="col-md-12 " style="display: inline-flex;">
                              <div class="col-md-6 col-sm-12 col-xs-12 col-lg-6 kl1">
                                 @if (!empty($SecondNote)) 
                                 @foreach ($SecondNote as $note)
                                 <p class="">
                                    <span class="btn-group" data-toggle="buttons">
                                    <label class="btn btnnp btn-success @if(in_array($note->id,$primary_habit)) active @endif ">
                                    <input type="checkbox" autocomplete="off" name="secondNotes[]" value="{{  $note->id }}" @if(in_array($note->id,$routine_habit)) checked @endif>
                                    @if(in_array($note->id,$routine_habit))<i class="fa fa-check"></i> @else <i class="f1 btnnp"></i> @endif 
                                    </label>
                                    </span>
                                   @if(in_array($note->id,$routine_habit)) <strike> {{  $note->NoteText }}  </strike> @else {{  $note->NoteText }}  @endif 
                                 </p>
                                 @endforeach
                                 @endif
                              </div>
                              <div class="col-md-6 col-sm-12 col-xs-12 col-lg-6 kl1">
                                 @if(!empty($second_simple_habit))  @php $i = 0 @endphp
                                 @foreach($second_simple_habit as $simplehabit)
                                 @if($simplehabit->Title !='')
                                 <div class="row">
                                    <div class="col-md-1 mb-3">
                                       <span class="btn-group" data-toggle="buttons">
                                       <label class="btn btnnp btn-success @if(in_array($note->id,$primary_habit)) active @endif ">
                                       <input type="checkbox" autocomplete="off" name="secondsimpleNotesstatus[{{ $i }}][0]" value="1" @if($simplehabit->IsActive == '1') checked @endif>
                                       @if($simplehabit->IsActive == '1')<i class="fa fa-check"></i> @else <i class="f1 btnnp"></i> @endif 
                                       </label>
                                       </span>
                                    </div>
                                    <div class="col-md-9 col-lg-10 mb-3">
                                       @if($simplehabit ->Title!='')
                                       <p class="pcls1">{{ $simplehabit ->Title }}</p>
                                       @endif
                                    </div>
                                 </div>
                                 @else
                                 @endif
                                 @php $i++ @endphp
                                 @endforeach
                                 @endif
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-md-12 col-sm-12 col-xs-12 col-lg-6 mb-3">
               <div class="panel panel-default">
                  <div class="panel-heading">Notes 
                     @if(!empty($notes_content))
                     @if(isset($notes_content[0]->NoteText)!='')
                     <a class="right-align"  data-toggle="modal" href="#notes-edit"><i class="fa fa-edit"></i></a>
                     <a class="right-align" data-toggle="modal" href="#notes-add"><i class="fa fa-plus"></i></a>
                     @else
                     <a class="right-align" data-toggle="modal" href="#notes-add"><i class="fa fa-plus"></i></a>
                     @endif
                     @else
                     <a class="right-align" data-toggle="modal" href="#notes-add"><i class="fa fa-plus"></i></a>
                     @endif
                  </div>
                  <div class="panel-body">
                     <div class="box">
                        @if(!empty($notes_content))
                        @foreach($notes_content as $notes)
                        @if($notes->NoteText!='')
                        <p class="pcls">{{ $notes->NoteText}}</p>
                        @endif
                        @endforeach
                        @else
                        <p class="pcls" style="text-align:center"> No Result Found</p>
                        @endif
                     </div>
                  </div>
               </div>
               <br>
               <div class="panel panel-default">
                  <div class="panel-heading">Creative Ideas 
                     @if(!empty($create_idea))
                     @if(isset($create_idea[0]->Title)!='')
                     <a class="right-align" data-toggle="modal" href="#idea-edit"> <i class="fa fa-edit"></i></a>
                     <a class="right-align" data-toggle="modal" href="#idea-add"><i class="fa fa-plus"></i></a>
                     @else
                     <a class="right-align" data-toggle="modal" href="#idea-add"><i class="fa fa-plus"></i></a>
                     @endif
                     @else
                     <a class="right-align" data-toggle="modal" href="#idea-add"><i class="fa fa-plus"></i></a>
                     @endif
                  </div>
                  <div class="panel-body">
                     <div class="box">
                        @if(!empty($create_idea)) @php $i = 0 @endphp
                        @foreach($create_idea as $create_ideas)
                        <div class="row">
                           <div class="col-md-1 mb-3 k2">
                              <span class="btn-group" data-toggle="buttons">
                              <label class="btn btn-success @if(in_array($note->id,$primary_habit)) active @endif ">
                              <input type="checkbox" autocomplete="off" name="ideaatus[0][]" value="1" @if($create_ideas->IsActive == '1') checked @endif>
                              @if($create_ideas->IsActive == '1')<i class="fa fa-check"></i> @else <i class="f1"></i> @endif 
                              </label>
                              </span>
                           </div>
                           <div class="col-lg-11 col-md-10 mb-3">
                              <input type="text" name="createiveidea[0][]" class="form-control f1" value="{{ $create_ideas->Title }}">             
                           </div>
                        </div>
                        @php $i++ @endphp
                        @endforeach
                        @else
                        <p class="pcls" style="text-align:center"> No Result Found</p>
                        @endif
                        <div id="Contentidea"></div>
                     </div>
                  </div>
               </div>
               <br>
               <div class="row">
                  <div class="col-md-12 col-sm-12 col-xs-12 col-lg-6 md-3 mg-5">
                     <div class="panel panel-default">
                        <div class="panel-heading">5 things that I hate 
                           @if(!empty($hates))
                           @if(isset($hates[0]->Title)!='')
                           <a class="right-align" data-toggle="modal" href="#5hate-edit"><i class="fa fa-edit"></i></a>
                           <a class="right-align" data-toggle="modal" href="#5hate-edit"><i class="fa fa-plus"></i></a> 
                           @else
                           <a class="right-align" data-toggle="modal" href="#5hate-edit"><i class="fa fa-plus"></i></a>
                           @endif
                           @else
                           <a class="right-align" data-toggle="modal" href="#5hate-edit"><i class="fa fa-plus"></i></a>
                           @endif
                        </div>
                        <div class="panel-body">
                           <div class="box">
                              @if(!empty($hates))              
                              @foreach($hates as $hate) 
                              @if($hate->Title!='') 
                              <p class="pcls">{{ $hate->Title}}</p>
                              @else
                              @endif
                              @endforeach
                              @else
                              @if(!empty($hates))
                              @if($hates[0]->Title=='')
                              <p class="pcls" style="text-align:center"> No Result Found</p>
                              @endif  @endif @endif
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-12 col-sm-12 col-xs-12 col-lg-6 md-3">
                     <div class="panel panel-default">
                        <div class="panel-heading" style="font-size: 14px;">5 things that I greatful for 
                           @if(!empty($likes))
                           @if(isset($likes[0]->Title)!='')
                           <a class="right-align" data-toggle="modal" href="#5like-edit"><i class="fa fa-edit" ></i></a> 
                           <a class="right-align" data-toggle="modal" href="#5like-edit"><i class="fa fa-plus"></i></a>
                           @else
                           <a class="right-align" data-toggle="modal" href="#5like-edit"><i class="fa fa-plus"></i></a>
                           @endif
                           @else
                           <a class="right-align" data-toggle="modal" href="#5like-edit"><i class="fa fa-plus"></i></a>
                           @endif             
                        </div>
                        <div class="panel-body">
                           <div class="box">
                              @if(!empty($likes))              
                              @foreach($likes as $like) 
                              @if($like->Title!='')
                              <p class="pcls">{{ $like->Title}}</p>
                              @else 
                              @endif
                              @endforeach
                              @else
                              <p class="pcls" style="text-align:center"> No Result Found</p>
                              @endif
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <br>
               <div class="row">
                  <div class="panel panel-default k1">
                     <div class="panel-heading">Home 
                        @if(!empty($home_content))
                        @if(isset($home_content[0]->NoteText)!='')
                        <a class="right-align" data-toggle="modal" href="#home-edit" ><i class="fa fa-edit"></i></a>
                        <a class="right-align" data-toggle="modal" href="#home-add"><i class="fa fa-plus"></i></a> 
                        @else
                        <a class="right-align" data-toggle="modal" href="#home-add"><i class="fa fa-plus"></i></a>
                        @endif
                        @else
                        <a class="right-align" data-toggle="modal" href="#home-add"><i class="fa fa-plus"></i></a>
                        @endif
                     </div>
                     <div class="panel-body">
                        <div class="box">
                           @if(!empty($home_content))
                           @foreach($home_content as $home)
                           @if($home->NoteText!='')
                           <p class="pcls">{{ $home->NoteText}}</p>
                           @endif   
                           @endforeach
                           @else
                           <p class="pcls" style="text-align:center"> No Result Found</p>
                           @endif
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
   </div>
   </form>
</div>
</div>
</div> 
@include('include.footer')
<script type="text/javascript">
   /* var today = "@php $currentDate = date('Y-m-d'); @endphp {{ $currentDate}}";
      $('#EntryDate').datepicker({
   format: "yyyy-mm-dd",
    endDate:today,
   });  
   $('#DairyDate').datepicker({
   format: "yyyy-mm-dd",
    endDate:today,
   });*/
</script> 
<script>
   var count = 0;
   function addmoretodo(){
    count += 1;     
    $(' <div class="row"><div class="col-md-11 mb-3"><input type="text" name="todotextnews['+count+'][]"  class="form-control"> </div> <div class="col-md-1 mb-3"> <label></label> <input type="checkbox" name="todostatusnews['+count+'][]" value="1">  </div> </div>').appendTo('#Content');            
    
   }              
</script>
<script>
   var count = 0;
    function addmoreidea(){
    count += 1;  
    $('<div class="row"><div class="col-md-10 col-lg-11 mb-3"><input type="text" name="createiveidea['+count+'][]" class="form-control"> </div><div class="col-md-1 mb-3"><label></label><input type="checkbox" name="ideaatus['+count+'][]" value="1"></div></div>').appendTo('#Contentidea');
    
   
   }
</script>
<script>
   function demo(datess){     
   $("#selecteddatehabit").html("<input type='hidden' name='currentdate' value='"+datess+"'>");
   document.getElementById("postform").submit();                        
   }
                    
</script>
<!-------------- Model divs part ----------------------------------------------------------------------->
<!-- wellnesshabits modal -->
<div id="wellnesshabits" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title">Wellness Habits</h4>
         </div>
         <div class="modal-body">
            <form method="post" id="wellnessid" name="wellnessid" action="{{ url('wellness-edit')}}">
               <input type="hidden" name="mynewdate" id="mynewdate" value="{{ $ajaxdate }}">
               {{csrf_field()}}
               <div class="box">
                  @if (!empty($PrimaryNote))
                  @foreach ($PrimaryNote as $note)
                  <div class="inbox">
                     <input type="checkbox" name="habit[]" value="{{  $note->id }}" @if(in_array($note->id,$primary_habit)) checked @endif>
                     {{  $note->NoteText }} 
                  </div>
                  @endforeach
                  @endif
               </div>
               <div class="btn-group">
                  <input type="submit" name="submit" value="Submit" class="btn btn-primary" >
                  <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>
               </div>
            </form>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<!-- End wellnesshabits modal -->
<!-- Marketing model edit functionality -->
<div id="market-edit" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title">
               Marketing <!--<a onclick="addmarketing()"  ><i class="fa fa-plus plus"></i></a>-->
            </h4>
         </div>
         <div class="modal-body">
            <form name="marketedit" id="marketedit" action="{{ url('market-form-edit') }}" method="POST">
               <div class="">
                  <input type="hidden" name="mynewdate" id="mynewdate" value="{{ $ajaxdate }}">
                  {{csrf_field()}}
                  @if(!empty($market_content))
                  @foreach($market_content as $marketing)
                  <div class="col-md-11 mb-3">
                     <input type="text" name="marketing[]" value="{{ $marketing->NoteText}}" class="form-control ">
                  </div>
                  @endforeach
                  @else 
                  <div class="col-md-11 mb-3">
                     <input type="text" name="marketing[]" value="" class="form-control ">
                  </div>
                  @endif
                  <div id="marketdiv"></div>
               </div>
               <div class="btn-group">
                  <button class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Save</button>
                  <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>
               </div>
            </form>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<script>
   var count = 0;
   function addmarketing(){
      count += 1; 
      $('<div class="col-md-11 mb-3"><input type="text" name="marketing[]" class="form-control"></div>').appendTo("#marketdiv");
   }
</script>
<!-- End  Marketing model edit functionality -->
<!-- Marketing model add functionality -->
<div id="market-add" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title">Marketing <a onclick="addmarketing1()"  ><i class="fa fa-plus plus"></i></a></h4>
         </div>
         <div class="modal-body">
            <form method="post" name="marketadd" id="marketadd" action="{{ url('market-form-add') }}">
               <input type="hidden" name="mynewdate" id="mynewdate" value="{{ $ajaxdate }}">
               {{csrf_field()}}
               <div class="">
                  <div class="col-md-11 mb-3">
                     <input type="text" name="marketing1[]" value="" class="form-control ">
                  </div>
                  <div id="marketdiv1"></div>
               </div>
               <div class="btn-group">
                  <button class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Save</button>
                  <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>
               </div>
            </form>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<script>
   var count = 0;
   function addmarketing1(){
      count += 1; 
      $('<div class="col-md-11 mb-3"><input type="text" name="marketing1[]" class="form-control"></div>').appendTo("#marketdiv1");
   }
</script>
<!-- End  Marketing model add functionality -->
<!-- To do model edit functionality -->
<div id="todo-edit" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title">
               To Do List <!--<a onclick="addmoretodo()"  ><i class="fa fa-plus plus"></i></a>-->
            </h4>
         </div>
         <div class="modal-body">
            <form action="{{ url('todo-form-edit') }}" method="post" name="todoedit" id="todoedit">
               <div class="">
                  <input type="hidden" name="mynewdate" id="mynewdate" value="{{ $ajaxdate }}">
                  {{csrf_field()}}
                  @if(!empty($todo)) @php $i = 0 @endphp
                  @if(isset($todo[0]->Title)!='')
                  @foreach($todo as $todolist)
                  <div class="row">
                     <div class="col-md-1 kl12">
                        <label></label>
                        <input type="checkbox" name="todostatusnews[{{$i}}][]" value="1" @if($todolist->IsActive) checked @endif>
                     </div>
                     <div class="col-md-10 col-lg-11 mb-3">
                        <input type="text" name="todotextnews[{{$i}}][]"  class="form-control" value="{{ $todolist->Title }}">                
                     </div>
                  </div>
                  @php $i++ @endphp
                  @endforeach
                  @endif
                  @endif
                  <div id="Contenttodo"></div>
               </div>
               <div class="btn-group">
                  <button class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Save</button>
                  <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>                        
               </div>
            </form>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<script>
   var v= "<?php if(!empty($todo)){ if(isset($todo[0]->Title)!=''){ echo $count = count($todo);} else {  echo '0';}}?>";
    var count= "<?php if(!empty($todo)){ if(isset($todo[0]->Title)!=''){ echo $count = count($todo);} else {  echo '0';}}?>";
    function addmoretodo(){
   var count= "<?php if(!empty($todo)){ if(isset($todo[0]->Title)!=''){ echo $count = count($todo);} else {  echo '0';}}?>";  
   $('<div class="row"> <div class="col-md-1 kl12"> <label></label> <input type="checkbox" name="todostatusnews['+count+'][]" value="1">  </div><div class="col-md-10 col-lg-11 mb-3"><input type="text" name="todotextnews['+count+'][]"  class="form-control"> </div> </div>').appendTo('#Contenttodo');            
     count += 1;  
   }  
</script>
<!-- End  To so model edit functionality -->
<!-- To do model add functionality -->
<div id="todo-add" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title">To Do List <a onclick="addmoretodo1()"  ><i class="fa fa-plus plus"></i></a></h4>
         </div>
         <div class="modal-body">
            <form name="todoadd" id="todoadd" action="{{ url('todo-form-add') }}" method="POST">
               <input type="hidden" name="mynewdate" id="mynewdate" value="{{ $ajaxdate }}">
               {{csrf_field()}}
               <div class="">
                  <div class="row">
                     <div class="col-md-1 col-lg-1 kl12">
                        <label></label>
                        <input type="checkbox" name="todostatusnewsss[0][]" value="1">
                     </div>
                     <div class="col-md-10 col-lg-11 mb-3">
                        <input type="text" name="todotextnewsss[0][]"  class="form-control" value="">                
                     </div>
                  </div>
                  <div id="Contenttodo1"></div>
               </div>
               <div class="btn-group">
                  <button class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Save</button>
                  <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>
               </div>
         </div>
         </form>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<script>
   var count = 0;
   function addmoretodo1(){
    count += 1;     
    $(' <div class="row"><div class="col-md-1 kl12"> <label></label> <input type="checkbox" name="todostatusnewsss['+count+'][]" value="1">  </div><div class="col-md-10 col-lg-11 mb-3"><input type="text" name="todotextnewsss['+count+'][]"  class="form-control"> </div>  </div>').appendTo('#Contenttodo1');            
    
   }     
</script>
<!-- End  To so model add functionality -->
<!-- Report model edit functionality -->
<div id="report-edit" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title">
               Reports <!--<a onclick="addmorereport()"  ><i class="fa fa-plus plus"></i></a>-->
            </h4>
         </div>
         <div class="modal-body">
            <div class="box">
               <form name="reportedit" id="reportedit" action="{{ url('report-form-edit') }}" method="POST">
                  <input type="hidden" name="mynewdate" id="mynewdate" value="{{ $ajaxdate }}">
                  {{csrf_field()}}
                  <div class="">
                     @if(!empty($report_content))
                     @foreach($report_content as $report)
                     <div class="col-md-11 mb-3"><input type="text" name="report[]" value="{{ $report->NoteText}}" class="form-control "></div>
                     @endforeach
                     @else 
                     <div class="col-md-11 mb-3"><input type="text" name="report[]" value="" class="form-control "></div>
                     @endif
                     <div id="reportdiv"></div>
                  </div>
                  <div class="btn-group">
                     <button class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Save</button>
                     <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>
                  </div>
               </form>
            </div>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<script>
   function addmorereport(){
      $('<div class="col-md-11 mb-3"><input type="text" name="report[]" class="form-control"></div>').appendTo("#reportdiv");
   }
</script>
<!-- End  Report model edit functionality -->
<!-- Report model add functionality -->
<div id="report-add" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title">Reports <a onclick="addmorereport1()"  ><i class="fa fa-plus plus"></i></a></h4>
         </div>
         <div class="modal-body">
            <div class="box">
               <form name="reportadd" id="reportadd" action="{{ url('report-form-add') }}" method="POST">
                  <input type="hidden" name="mynewdate" id="mynewdate" value="{{ $ajaxdate }}">
                  {{csrf_field()}}
                  <div class="">
                     <div class="col-md-11 mb-3"><input type="text" name="reports[]" value="" class="form-control "></div>
                     <div id="reportdivs"></div>
                  </div>
                  <div class="btn-group">
                     <button class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Save</button>
                     <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>                        
                  </div>
               </form>
            </div>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<script>
   function addmorereport1(){
      $('<div class="col-md-11 mb-3"><input type="text" name="reports[]" class="form-control"></div>').appendTo("#reportdivs");
   }
</script>
<!-- End  Report model add functionality -->
<!-- Routine habit modal edit functionality -->
<div id="routine-habit-add" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title">Daily Routine habit </h4>
         </div>
         <div class="modal-body">
            <div class="box">
               <form name="notesedit" id="notesedit" action="{{ url('routine-form-edit') }}" method="POST">
                  <input type="hidden" name="mynewdate" id="mynewdate" value="{{ $ajaxdate }}">
                  {{csrf_field()}}
                  <div class="row">
                     <div class="col-md-12" style="display: inline-flex;">
                        <div class="col-md-6 kl1">
                           @if (!empty($SecondNote)) 
                           @foreach ($SecondNote as $note)
                           <p class="">
                              <input type="checkbox" autocomplete="off" name="secondNotes[]" value="{{  $note->id }}" @if(in_array($note->id,$routine_habit)) checked @endif>
                              {{  $note->NoteText }}  
                           </p>
                           @endforeach
                           @endif
                        </div>
                        <div class="col-md-6 kl1">
                           <div class="row">
                              <div class="col-md-1 mb-3"><input type="checkbox" autocomplete="off" name="secondsimpleNotesstatus[0][0]" value="1" @if(isset($second_simple_habit[0]->IsActive)) @if($second_simple_habit[0]->IsActive=='1') checked @endif @endif></div>
                              <div class="col-md-10 mb-3">
                                 @if(isset($second_simple_habit[0]->Title)!='')
                                 <input type="text" name="secondsimpleNotes[0][0]" class="form-control c1" value="{{ $second_simple_habit[0] ->Title }}">
                                 @else
                                 <input type="text" name="secondsimpleNotes[0][0]" class="form-control c1" value="">
                                 @endif
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-1 mb-3"><input type="checkbox" autocomplete="off" name="secondsimpleNotesstatus[1][0]" value="1" @if(isset($second_simple_habit[1]->IsActive)) @if($second_simple_habit[1]->IsActive=='1') checked @endif @endif></div>
                              <div class="col-md-10 mb-3">
                                 @if(isset($second_simple_habit[1]->Title)!='')
                                 <input type="text" name="secondsimpleNotes[1][0]" class="form-control c1" value="{{ $second_simple_habit[1] ->Title }}">
                                 @else
                                 <input type="text" name="secondsimpleNotes[1][0]" class="form-control c1" value="">
                                 @endif
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-1 mb-3"><input type="checkbox" autocomplete="off" name="secondsimpleNotesstatus[2][0]" value="1" @if(isset($second_simple_habit[2]->IsActive)) @if($second_simple_habit[2]->IsActive=='1') checked @endif @endif></div>
                              <div class="col-md-10 mb-3">
                                 @if(isset($second_simple_habit[2]->Title)!='')
                                 <input type="text" name="secondsimpleNotes[2][0]" class="form-control c1" value="{{ $second_simple_habit[2] ->Title }}">
                                 @else
                                 <input type="text" name="secondsimpleNotes[2][0]" class="form-control c1" value="">
                                 @endif
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-1 mb-3"><input type="checkbox" autocomplete="off" name="secondsimpleNotesstatus[3][0]" value="1" @if(isset($second_simple_habit[3]->IsActive)) @if($second_simple_habit[3]->IsActive=='1') checked @endif @endif></div>
                              <div class="col-md-10 mb-3">
                                 @if(isset($second_simple_habit[3]->Title)!='')
                                 <input type="text" name="secondsimpleNotes[3][0]" class="form-control c1" value="{{ $second_simple_habit[3] ->Title }}">
                                 @else
                                 <input type="text" name="secondsimpleNotes[3][0]" class="form-control c1" value="">
                                 @endif
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-1 mb-3"><input type="checkbox" autocomplete="off" name="secondsimpleNotesstatus[4][0]" value="1" @if(isset($second_simple_habit[4]->IsActive)) @if($second_simple_habit[4]->IsActive=='1') checked @endif @endif></div>
                              <div class="col-md-10 mb-3">
                                 @if(isset($second_simple_habit[4]->Title)!='')
                                 <input type="text" name="secondsimpleNotes[4][0]" class="form-control c1" value="{{ $second_simple_habit[4] ->Title }}">
                                 @else
                                 <input type="text" name="secondsimpleNotes[4][0]" class="form-control c1" value="">
                                 @endif
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-1 mb-3"><input type="checkbox" autocomplete="off" name="secondsimpleNotesstatus[5][0]" value="1" @if(isset($second_simple_habit[5]->IsActive)) @if($second_simple_habit[5]->IsActive=='1') checked @endif @endif></div>
                              <div class="col-md-10 mb-3">
                                 @if(isset($second_simple_habit[5]->Title)!='')
                                 <input type="text" name="secondsimpleNotes[5][0]" class="form-control c1" value="{{ $second_simple_habit[5] ->Title }}">
                                 @else
                                 <input type="text" name="secondsimpleNotes[5][0]" class="form-control c1" value="">
                                 @endif
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-1 mb-3"><input type="checkbox" autocomplete="off" name="secondsimpleNotesstatus[6][0]" value="1" @if(isset($second_simple_habit[6]->IsActive)) @if($second_simple_habit[6]->IsActive=='1') checked @endif @endif></div>
                              <div class="col-md-10 mb-3">
                                 @if(isset($second_simple_habit[6]->Title)!='')
                                 <input type="text" name="secondsimpleNotes[6][0]" class="form-control c1" value="{{ $second_simple_habit[6] ->Title }}">
                                 @else
                                 <input type="text" name="secondsimpleNotes[6][0]" class="form-control c1" value="">
                                 @endif
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-1 mb-3"><input type="checkbox" autocomplete="off" name="secondsimpleNotesstatus[7][0]" value="1" @if(isset($second_simple_habit[7]->IsActive)) @if($second_simple_habit[7]->IsActive=='1') checked @endif @endif></div>
                              <div class="col-md-10 mb-3">
                                 @if(isset($second_simple_habit[7]->Title)!='')
                                 <input type="text" name="secondsimpleNotes[7][0]" class="form-control c1" value="{{ $second_simple_habit[7] ->Title }}">
                                 @else
                                 <input type="text" name="secondsimpleNotes[7][0]" class="form-control c1" value="">
                                 @endif
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-1 mb-3"><input type="checkbox" autocomplete="off" name="secondsimpleNotesstatus[8][0]" value="1" @if(isset($second_simple_habit[8]->IsActive)) @if($second_simple_habit[8]->IsActive=='1') checked @endif @endif></div>
                              <div class="col-md-10 mb-3">
                                 @if(isset($second_simple_habit[8]->Title)!='')
                                 <input type="text" name="secondsimpleNotes[8][0]" class="form-control c1" value="{{ $second_simple_habit[8] ->Title }}">
                                 @else
                                 <input type="text" name="secondsimpleNotes[8][0]" class="form-control c1" value="">
                                 @endif
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-1 mb-3"><input type="checkbox" autocomplete="off" name="secondsimpleNotesstatus[9][0]" value="1" @if(isset($second_simple_habit[9]->IsActive)) @if($second_simple_habit[9]->IsActive=='1') checked @endif @endif></div>
                              <div class="col-md-10 mb-3">
                                 @if(isset($second_simple_habit[9]->Title)!='')
                                 <input type="text" name="secondsimpleNotes[9][0]" class="form-control c1" value="{{ $second_simple_habit[9] ->Title }}">
                                 @else
                                 <input type="text" name="secondsimpleNotes[9][0]" class="form-control c1" value="">
                                 @endif
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-1 mb-3"><input type="checkbox" autocomplete="off" name="secondsimpleNotesstatus[10][0]" value="1" @if(isset($second_simple_habit[10]->IsActive)) @if($second_simple_habit[10]->IsActive=='1') checked @endif @endif></div>
                              <div class="col-md-10 mb-3">
                                 @if(isset($second_simple_habit[10]->Title)!='')
                                 <input type="text" name="secondsimpleNotes[10][0]" class="form-control c1" value="{{ $second_simple_habit[10] ->Title }}">
                                 @else
                                 <input type="text" name="secondsimpleNotes[10][0]" class="form-control c1" value="">
                                 @endif
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-1 mb-3"><input type="checkbox" autocomplete="off" name="secondsimpleNotesstatus[11][0]" value="1" @if(isset($second_simple_habit[11]->IsActive)) @if($second_simple_habit[11]->IsActive=='1') checked @endif @endif></div>
                              <div class="col-md-10 mb-3">
                                 @if(isset($second_simple_habit[11]->Title)!='')
                                 <input type="text" name="secondsimpleNotes[11][0]" class="form-control c1" value="{{ $second_simple_habit[11] ->Title }}">
                                 @else
                                 <input type="text" name="secondsimpleNotes[11][0]" class="form-control c1" value="">
                                 @endif
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-1 mb-3"><input type="checkbox" autocomplete="off" name="secondsimpleNotesstatus[12][0]" value="1" @if(isset($second_simple_habit[12]->IsActive)) @if($second_simple_habit[12]->IsActive=='1') checked @endif @endif></div>
                              <div class="col-md-10 mb-3">
                                 @if(isset($second_simple_habit[12]->Title)!='')
                                 <input type="text" name="secondsimpleNotes[12][0]" class="form-control c1" value="{{ $second_simple_habit[12] ->Title }}">
                                 @else
                                 <input type="text" name="secondsimpleNotes[12][0]" class="form-control c1" value="">
                                 @endif
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-1 mb-3"><input type="checkbox" autocomplete="off" name="secondsimpleNotesstatus[13][0]" value="1" @if(isset($second_simple_habit[13]->IsActive)) @if($second_simple_habit[13]->IsActive=='1') checked @endif @endif></div>
                              <div class="col-md-10 mb-3">
                                 @if(isset($second_simple_habit[13]->Title)!='')
                                 <input type="text" name="secondsimpleNotes[13][0]" class="form-control c1" value="{{ $second_simple_habit[13] ->Title }}">
                                 @else
                                 <input type="text" name="secondsimpleNotes[13][0]" class="form-control c1" value="">
                                 @endif
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="btn-group">
                     <button class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Save</button>
                     <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>
                  </div>
               </form>
            </div>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<script>
   function addmorereport(){
      $('<div class="col-md-11 mb-3"><input type="text" name="report[]" class="form-control"></div>').appendTo("#reportdiv");
   }
</script>
<!-- End Routine habit modal edit functionality -->
<!-- Routine notes modal edit functionality -->
<div id="notes-edit" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title">
               Notes <!--<a onclick="addmorenotes()"  class="addmore"><i class="fa fa-plus plus"></i></a>-->
            </h4>
         </div>
         <div class="modal-body">
            <div class="box">
               <form name="notesedit" id="notesedit" action="{{ url('notes-form-edit') }}" method="POST">
                  <input type="hidden" name="mynewdate" id="mynewdate" value="{{ $ajaxdate }}">
                  {{csrf_field()}}
                  <div class="">
                     @if(!empty($notes_content))
                     @foreach($notes_content as $notes)
                     <div class="col-md-11 mb-3"><input type="text" name="notes[]" value="{{ $notes->NoteText}}" class="form-control "></div>
                     @endforeach
                     @else
                     <div class="col-md-11 mb-3"><input type="text" name="notes[]" value="" class="form-control "></div>
                     @endif
                     <div id="notesdiv"></div>
                  </div>
                  <div class="btn-group">
                     <button class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Save</button>
                     <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>
                  </div>
               </form>
            </div>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<script>
   function addmorenotes()
   {
      $('<div class="col-md-11 mb-3"><input type="text" name="notes[]" class="form-control"></div>').appendTo("#notesdiv");
   }
    
</script>
<!-- End Notes modal edit functionality -->
<!-- Routine notes modal add functionality -->
<div id="notes-add" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title" style="width: 100%;">Notes <a onclick="addmorenotes1()"  class="addmore"><i class="fa fa-plus plus"></i></a></h4>
         </div>
         <div class="modal-body">
            <div class="box">
               <form name="notesedit" id="notesedit" action="{{ url('notes-form-add') }}" method="POST">
                  <input type="hidden" name="mynewdate" id="mynewdate" value="{{ $ajaxdate }}">
                  {{csrf_field()}}
                  <div class="">
                     <div class="col-md-11 mb-3"><input type="text" name="notesss[]" value="" class="form-control "></div>
                     <div id="notesdivss"></div>
                  </div>
                  <div class="btn-group">
                     <button class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Save</button>
                     <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>
                  </div>
               </form>
            </div>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<script>
   function addmorenotes1()
   {
      $('<div class="col-md-11 mb-3"><input type="text" name="notesss[]" class="form-control"></div>').appendTo("#notesdivss");
   }
    
</script>
<!-- End Notes modal add functionality -->
<!-- Creative ideas modal edit functionality -->
<div id="idea-edit" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title">
               Creative Ideas <!--<a onclick="addmoreidea()"  class="addmore"><i class="fa fa-plus plus"></i></a>-->
            </h4>
         </div>
         <div class="modal-body">
            <div class="box">
               <form name="ideaedit" id="ideaedit" action="{{ url('idea-form-edit') }}" method="POST">
                  <input type="hidden" name="mynewdate" id="mynewdate" value="{{ $ajaxdate }}">
                  {{csrf_field()}}
                  <div class="">
                     @if(!empty($create_idea))
                     @php $i = 0 @endphp
                     @if(isset($create_idea[0]->Title)!='')
                     @foreach($create_idea as $create_ideas)
                     <div class="row">
                        <div class="col-md-1 mb-3">
                           <label></label>
                           <input type="checkbox" name="ideaatus[{{$i}}][]" value="1"  @if($create_ideas->IsActive == '1') checked @endif>
                        </div>
                        <div class="col-md-10 sok-lg-11 mb-3">
                           <input type="text" name="createiveidea[{{$i}}][]" class="form-control" value="{{ $create_ideas->Title }}">             
                        </div>
                     </div>
                     @php $i++ @endphp
                     @endforeach
                     @else
                     @endif
                     @endif
                     <div id="Contentidea1"></div>
                  </div>
                  <div class="btn-group">
                     <button class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Save</button>
                     <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>
                  </div>
               </form>
            </div>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<script>
   var count = 0;
    function addmoreidea(){
    count += 1;  
    $('<div class="row"><div class="col-md-1 mb-3"><label></label><input type="checkbox" name="ideaatus['+count+'][]" value="1"></div><div class="col-md-10 col-lg-11 mb-3"><input type="text" name="createiveidea['+count+'][]" class="form-control"> </div></div>').appendTo('#Contentidea1');
                             
   }
    
</script>
<!-- End Creative ideas modal edit functionality -->
<!-- Creative ideas modal add functionality -->
<div id="idea-add" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title" style="width: 100%;">Creative Ideas <a onclick="addmoreidea1()"  class="addmore"><i class="fa fa-plus plus"></i></a></h4>
         </div>
         <div class="modal-body">
            <div class="box">
               <form name="ideaedit" id="ideaadd" action="{{ url('idea-form-add') }}" method="POST">
                  <input type="hidden" name="mynewdate" id="mynewdate" value="{{ $ajaxdate }}">
                  {{csrf_field()}}
                  <div class="">
                     <div class="row">
                        <div class="col-md-1 mb-3">
                           <label></label>
                           <input type="checkbox" name="ideaatus[0][]" value="1"  >
                        </div>
                        <div class="col-md-10 col-lg-11 mb-3">
                           <input type="text" name="createiveidea[0][]" class="form-control" value="">             
                        </div>
                     </div>
                     <div id="Contentidea2"></div>
                  </div>
                  <div class="btn-group">
                     <button class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Save</button>
                     <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>
                  </div>
               </form>
            </div>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<script>
   var count = 0;
    function addmoreidea1(){
    count += 1;  
    $('<div class="row"><div class="col-md-1 mb-3"><label></label><input type="checkbox" name="ideaatus['+count+'][]" value="1"></div><div class="col-md-10 col-lg-11 mb-3"><input type="text" name="createiveidea['+count+'][]" class="form-control"> </div></div>').appendTo('#Contentidea2');
                             
   }
    
</script>
<!-- End Creative ideas modal add functionality -->
<!-- 5 hate modal edit functionality -->
<div id="5hate-edit" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title">5 things that I hate </h4>
         </div>
         <div class="modal-body">
            <div class="box">
               <form name="hateedit" id="hateedit" action="{{ url('hate-form-edit') }}" method="POST">
                  <input type="hidden" name="mynewdate" id="mynewdate" value="{{ $ajaxdate }}">
                  {{csrf_field()}}
                  <div class="">
                     <input type="text" name="fivehatenote[0]" class="form-control b1" value="@if(isset($hates[0]->Title)!='') {{$hates[0]->Title }}@endif"> 
                     <input type="text" name="fivehatenote[1]" class="form-control b1" value="@if(isset($hates[1]->Title)!='') {{ $hates[1]->Title }} @endif"> 
                     <input type="text" name="fivehatenote[2]" class="form-control b1" value="@if(isset($hates[2]->Title)!='') {{ $hates[2]->Title }} @endif"> 
                     <input type="text" name="fivehatenote[3]" class="form-control b1" value="@if(isset($hates[3]->Title)!='') {{ $hates[3]->Title }} @endif"> 
                     <input type="text" name="fivehatenote[4]" class="form-control b1" value="@if(isset($hates[4]->Title)!='') {{ $hates[4]->Title }} @endif"> 
                  </div>
                  <div class="btn-group">
                     <button class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Save</button>
                     <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>                        
                  </div>
               </form>
            </div>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<!-- End 5 hate modal edit functionality -->
<!-- 5 like modal edit functionality -->
<div id="5like-edit" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title">5 things that I grateful for </h4>
         </div>
         <div class="modal-body">
            <div class="box">
               <form name="likeedit" id="likeedit" action="{{ url('like-form-edit') }}" method="POST">
                  <input type="hidden" name="mynewdate" id="mynewdate" value="{{ $ajaxdate }}">
                  {{csrf_field()}}
                  <div class="">
                     <input type="text" name="fivelikenote[0]" class="form-control b1" value="@if(isset($likes[0]->Title)!='') {{$likes[0]->Title }}@endif"> 
                     <input type="text" name="fivelikenote[1]" class="form-control b1" value="@if(isset($likes[1]->Title)!='') {{ $likes[1]->Title }} @endif"> 
                     <input type="text" name="fivelikenote[2]" class="form-control b1" value="@if(isset($likes[2]->Title)!='') {{ $likes[2]->Title }} @endif"> 
                     <input type="text" name="fivelikenote[3]" class="form-control b1" value="@if(isset($likes[3]->Title)!='') {{ $likes[3]->Title }} @endif"> 
                     <input type="text" name="fivelikenote[4]" class="form-control b1" value="@if(isset($likes[4]->Title)!='') {{ $likes[4]->Title }} @endif"> 
                  </div>
                  <div class="btn-group">
                     <button class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Save</button>
                     <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>
                  </div>
               </form>
            </div>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<!-- End 5 like modal edit functionality -->
<!-- edit home functionality -->
<div id="home-edit" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title" >
               Home <!--<a onclick="addmorehome()"  class="addmore"><i class="fa fa-plus plus"></i></a>-->
            </h4>
         </div>
         <div class="modal-body">
            <div class="box">
               <form name="homeedit" id="homeedit" action="{{ url('home-form-edit') }}" method="POST">
                  <input type="hidden" name="mynewdate" id="mynewdate" value="{{ $ajaxdate }}">
                  {{csrf_field()}}
                  <div class="">
                     @if(!empty($home_content))
                     @foreach($home_content as $home)
                     <div class="col-md-11 mb-3"><input type="text" name="home[]" value="{{ $home->NoteText}}" class="form-control c1"></div>
                     @endforeach
                     @else
                     <div class="col-md-11 mb-3"><input type="text" name="home[]" value="" class="form-control "></div>
                     @endif
                     <div id="homediv"></div>
                  </div>
                  <div class="btn-group">
                     <button class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Save</button>
                     <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>                        
                  </div>
               </form>
            </div>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<script>
   function addmorehome(){   
      $('<div class="col-md-11 mb-3"><input type="text" name="home[]" class="form-control"></div>').appendTo("#homediv");
   }
</script>
<!-- End home edit functionality -->
<!-- add home functionality -->
<div id="home-add" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title" style="width: 100%;">Home <a onclick="addmorehome1()"  class="addmore"><i class="fa fa-plus plus"></i></a></h4>
         </div>
         <div class="modal-body">
            <div class="box">
               <form name="homeadd" id="homeadd" action="{{ url('home-form-add') }}" method="POST">
                  <input type="hidden" name="mynewdate" id="mynewdate" value="{{ $ajaxdate }}">
                  {{csrf_field()}}
                  <div class="">
                     <div class="col-md-11 mb-3"><input type="text" name="homess[]" value="" class="form-control "></div>
                     <div id="homediv1"></div>
                  </div>
                  <div class="btn-group">
                     <button class="btn btn-primary"><span class="glyphicon glyphicon-check"></span> Save</button>
                     <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>
                  </div>
               </form>
            </div>
         </div>
         <div class="modal-footer">
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<script>
   function addmorehome1(){   
      $('<div class="col-md-11 mb-3"><input type="text" name="homess[]" class="form-control"></div>').appendTo("#homediv1");
   }
</script>
<!-- End home add functionality -->
@endsection