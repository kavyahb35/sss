@extends('layout.inner')
@section('content')
	  @if ($errors->any())
	  <div class="alert alert-danger">
		  <ul>
			  @foreach ($errors->all() as $error)
				  <li>{{ $error }}</li>
			  @endforeach
		  </ul>
	  </div><br />
	  @endif
	   @if (\Session::has('success'))
      <div class="alert alert-success">
          <p>{{ \Session::get('success') }}</p>
      </div><br />
      @endif
		<h4> Create New Schedule </h4>
            <form method="post" action="{{ url('update-entry/'.$thirdNote[0]->EntryId) }}">
         <input   type="text" placeholder="click to show datepicker" name="EntryDate" value="{{  $thirdNote[0]->EntryDate }}" readonly style="float:right" >
               <input type="submit" name="submit" value="submit">
                {{csrf_field()}}
                <input type="hidden" name="EnterId" value="{{ $thirdNote[0]->EntryId }}">
                <div class="tab1" id="tab1">
                <div class="col-md-8">
                 <h4>Predefine with status </h4>
                    <div class="form-group">
                        <label class="sr-only">Habit</label>
                        <div class="box">
                        @if (!empty($PrimaryNote))
                            @foreach ($PrimaryNote as $note)
                            <p class="inbox"><input type="checkbox" name="habit[]" value="{{  $note->id }}"> {{  $note->NoteText }} </p>
                            @endforeach
                        @endif
                        </div>
                    </div>
              </div>
              <div class="col-md-4">
                 <h4>Marketing</h4>
                    <div class="form-group">
                        <textarea name="marketing" class="form-control"></textarea>
                    </div>
               </div>
                </div>

               <div class="tab2" id="tab2">
                <div class="col-md-12">
                 <h4>To Do List  <a onclick="addmoretodo()" style="float:right">Add more</a> </h4>
                    <div class="form-group">
                    <div class="col-md-11">
                       <input type="text" name="todotextnews[0][]"  class="form-control">
                       </div>
                       <div class="col-md-1">
                       <input type="checkbox" name="todostatusnews[0][]" value="1">
                      
                        </div>
                    </div>
                  
                    <!------------------------------------->
                    <!------------>
                    
              <div id="Content"></div>
               <script>
              var count = 0;
              function addmoretodo(){
				  count += 1;                 
                  $('<div class="form-group"><div class="col-md-11"> <input type="text" name="todotextnews['+count+'][]" class="form-control"></div><div class="col-md-1"><input type="checkbox" name="todostatusnews['+count+'][]" value="1"></div></div>').appendTo('#Content');
              }              
              </script>
              
              <script>
              var count = 0;
               function addmoreidea(){
				     count += 1;  
                  $('<div class="form-group"><div class="col-md-11"> <input type="text" name="createiveidea['+count+'][]" class="form-control"></div> <div class="col-md-1"><input type="checkbox" name="ideaatus['+count+'][]" value="1"></div> </div>').appendTo('#Contentidea');
              }
              </script>
                            
              </div>
             
               </div>
              
              
              
                <div class="tab3" id="tab3">
                <div class="col-md-6">
                 <h4>Report </h4>
                    <div class="form-group">
                       <textarea type="text" name="report" class="form-control" rows="10" ></textarea>
                  </div> 
                </div>
                
                
                <div class="col-md-6">
                
                    <div class="form-group">
                     <h4>Notes </h4>
                       <textarea type="text" name="notes" class="form-control"></textarea>
                  </div> 
                  
                  <div class="form-group">
                     <h4>Creative Idea <a onclick="addmoreidea()" style="float:right">Add more</a> </h4>
                         <div class="col-md-12">
                         
                            <div class="form-group">
                            <div class="col-md-11">
                               <input type="text" name="createiveidea[0][]" class="form-control">
                               </div>
                               <div class="col-md-1">
                               <input type="checkbox" name="ideaatus[0][]" value="1">
                                </div>
                            </div>
                      <div id="Contentidea"></div>
                                    
                      </div>
                     
                  </div> 
                  
                </div>
                
                
               </div>
              
              
              <div class="tab4" id="tab4">
                <div class="col-md-3">
                 <h4> Secondary predefine note  <!--<a onclick="addmoretodo()" style="float:right">Add more</a> --></h4>
                    <div class="form-group">
                      @if (!empty($SecondNote))
                            @foreach ($SecondNote as $note)
                            <p class=""><input type="checkbox" name="secondNotes[]" value="{{  $note->id }}"> {{  $note->NoteText }} </p>
                            @endforeach
                        @endif
                    </div>
                </div>
             
                <div class="col-md-3">
                 <h4> Secondary predefine note  <!--<a onclick="addmoretodo()" style="float:right">Add more</a> --></h4>
                    <div class="form-group">
                    
                      @if (!empty($SecondNote))               @php $i = 0 @endphp
                            @foreach ($SecondNote as $note) 
                            <div class="col-md-11"><input type="text" name="secondsimpleNotes[{{ $i }}][0]" class="form-control" value=""> </div>
                            <div class="col-md-1"><input type="checkbox" name="secondsimpleNotesstatus[{{ $i }}][0]" value="1"> </div>
                           @php $i++ @endphp
                            @endforeach
                        @endif
                    </div>
                </div>
             
              <div class="col-md-6">
                <div class="col-md-6">
                <h4> Five Hate note</h4>
                    <input type="text" name="fivehatenote[]" class="form-control" value=""> 
                    <input type="text" name="fivehatenote[]" class="form-control" value=""> 
                    <input type="text" name="fivehatenote[]" class="form-control" value=""> 
                    <input type="text" name="fivehatenote[]" class="form-control" value=""> 
                    <input type="text" name="fivehatenote[]" class="form-control" value=""> 
                </div>
                
                <div class="col-md-6">
                    <h4> Five greatefull for</h4>
                    <input type="text" name="fivelikenote[]" class="form-control" value=""> 
                    <input type="text" name="fivelikenote[]" class="form-control" value=""> 
                    <input type="text" name="fivelikenote[]" class="form-control" value=""> 
                    <input type="text" name="fivelikenote[]" class="form-control" value=""> 
                    <input type="text" name="fivelikenote[]" class="form-control" value=""> 
                </div>
                
                
                <div class="col-md-12">
                <h4>Home</h4>
                <textarea class="form-control" name="home"></textarea>
                </div>
              </div>
              
              </div>
             
         </form>
			
             
              <style>
              .content-wrapper {
    overflow: scroll !important;
}
                  .box {
                        display: inline-block;
                        width: 100%;
                        
                    }
                    p.inbox {
                    display: inline-table;
                    width: 19%;
                }
              </style>
              
@endsection
