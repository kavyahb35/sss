@extends('layout.inner')
@section('content')
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
   <h1 class="h2">Daily Diary </h1>
   <!--<span style="float:right; font-size: 27px;font-weight: bold;"></span>   -->
</div>
<div class="row">
   <div class="col-md-12 order-md-1">
      <form method="post" action="{{ url('update-entry/'.$thirdNote[0]->EntryId) }}">
         <input   type="hidden" placeholder="click to show datepicker" name="EntryDate" value="{{  $thirdNote[0]->EntryDate }}" readonly style="float:right" >
         {{csrf_field()}}
         <input type="hidden" name="EnterId" value="{{ $thirdNote[0]->EntryId }}">
         <div class="row">
            <div class="col-md-8 mb-3">
         <div class="panel panel-default">
              <div class="panel-heading">Pre define notes with status</div>
              <div class="panel-body">
                <div class="box">
                     @if (!empty($PrimaryNote))
                   @foreach ($PrimaryNote as $note)
                     <p class="inbox"><input type="checkbox" name="habit[]" value="{{  $note->id }}"> {{  $note->NoteText }} </p>
                   @endforeach
                     @endif
                  </div>
              </div>
            </div>
            
              
            </div>
            <div class="col-md-4 mb-3">
         <div class="panel panel-default">
              <div class="panel-heading">Marketing <a onclick="addmarketing()" class="addmore"><i class="fa fa-plus plus"></i></a></div>
              <div class="panel-body">
                <div class="">
                    <div class="col-md-11 mb-3"><input type="text" name="marketing[]" class="form-control "></div>
                  <div id="marketdiv"></div>
                  </div>
              </div>
            </div>
             
            </div>
         </div>
       
       <div class="panel panel-default">
              <div class="panel-heading">To Do List <a onclick="addmoretodo()"  class="addmore"><i class="fa fa-plus plus"></i></a></div>
              <div class="panel-body">
                <div class="">
                  <div class="row">
            
            <div class="col-md-1 kl1">
               <label></label>
               <input type="checkbox" name="todostatusnews[0][]" value="1">
            </div>
            <div class="col-md-11 mb-3">
               <input type="text" name="todotextnews[0][]"  class="form-control">                
            </div>
         </div>
        <div id="Content"></div>
       
                  </div>
              </div>
            </div>
            
            <br>
         <div class="row">
            <div class="col-md-6 mb-3">
               
            
            <div class="panel panel-default">
              <div class="panel-heading">Report <a onclick="addmorereport()"  class="addmore"><i class="fa fa-plus plus"></i></a></div>
              <div class="panel-body">
                <div class="">
                    <div class="col-md-11 mb-3"><input type="text" name="report[]" class="form-control "></div>
                  <div id="reportdiv"></div>
                  </div>
              </div>
            </div>
            
             <br>
               <div class="border-box">
                  <div class="row">
                     <div class="col-md-6 mb-3">
                
                <div class="panel panel-default">
              <div class="panel-heading">Predefine note with status</div>
              <div class="panel-body">
                <div class="">
                     @if (!empty($SecondNote))
                        @foreach ($SecondNote as $note)
                           <p class=""><input type="checkbox" name="secondNotes[]" value="{{  $note->id }}"> {{  $note->NoteText }} </p>
                        @endforeach
                           @endif 
                  </div>
              </div>
            </div>
            
                        
                     </div> <br>
                     <div class="col-md-6 mb-3">
                
                <div class="panel panel-default">
              <div class="panel-heading">Simple note with status</div>
              <div class="panel-body">
                <div class="">
                    @for ($i = 1; $i < 14; $i++)
                           <div class="row">
                              <div class="col-md-1 mb-3"><input type="checkbox" name="secondsimpleNotesstatus[{{ $i }}][0]" value="1"> </div>

                              <div class="col-md-11 mb-3"><input type="text" name="secondsimpleNotes[{{ $i }}][0]" class="form-control c1" value=""> </div>
                           </div>
                           @endfor
                  </div>
              </div>
            </div>
                       
                     </div>
                  </div>
               </div>
            </div> <br>
            <div class="col-md-6 mb-3">
         
         <div class="panel panel-default">
              <div class="panel-heading">Notes <a onclick="addmorenotes()"  class="addmore"><i class="fa fa-plus plus"></i></a></div>
              <div class="panel-body">
                <div class="">
                     <div class="col-md-11 mb-3"><input type="text" name="notes[]" class="form-control "></div>
                  <div id="notesdiv"></div>
                  </div>
              </div>
            </div>
            
             
               <br>
            
            <div class="panel panel-default">
              <div class="panel-heading">Creative Idea <a onclick="addmoreidea()"  class="addmore"><i class="fa fa-plus plus"></i></a></div>
              <div class="panel-body">
                <div class="">
                     <div class="row">
                     
                     <div class="col-md-1 mb-3">
                        <label></label>
                        <input type="checkbox" name="ideaatus[0][]" value="1">
                     </div>
                     <div class="col-md-11 mb-3">
                        <input type="text" name="createiveidea[0][]" class="form-control">             
                     </div>
                  </div>
                  <div id="Contentidea"></div>
                  </div>
              </div>
            </div>
            
                <br>
               <div class="row"> 
                  <div class="col-md-6 md-3">
              <div class="panel panel-default">
              <div class="panel-heading">5 things that i hate</div>
              <div class="panel-body">
                <div class="">
                     <input type="text" name="fivehatenote[]" class="form-control b1" value=""> 
                        <input type="text" name="fivehatenote[]" class="form-control b1" value=""> 
                        <input type="text" name="fivehatenote[]" class="form-control b1" value=""> 
                        <input type="text" name="fivehatenote[]" class="form-control b1" value=""> 
                        <input type="text" name="fivehatenote[]" class="form-control b1" value=""> 
                  </div>
              </div>
            </div>
            
                     
                  </div>
                  <div class="col-md-6 md-3">
              <div class="panel panel-default">
              <div class="panel-heading">5 things that i greatful for</div>
              <div class="panel-body">
                <div class="">
                     <input type="text" name="fivelikenote[]" class="form-control b1" value=""> 
                        <input type="text" name="fivelikenote[]" class="form-control b1" value=""> 
                        <input type="text" name="fivelikenote[]" class="form-control b1" value=""> 
                        <input type="text" name="fivelikenote[]" class="form-control b1" value=""> 
                        <input type="text" name="fivelikenote[]" class="form-control b1" value=""> 
                  </div>
              </div>
            </div>
                     
                  </div>
               </div> <br>
            <div class="panel panel-default">
              <div class="panel-heading">Home <a onclick="addmorehome()"  class="addmore"><i class="fa fa-plus plus"></i></a></div>
              <div class="panel-body">
                <div class="">
                    <div class="col-md-11 mb-3">   <input type="text" name="home[]" class="form-control "></div>
                  <div id="homediv"></div>
                  </div>
              </div>
            </div>
            
               
               <br>
               <div class="row">
                  <input type="submit" name="submit" value="Submit" class="btn btn-primary">&nbsp;&nbsp;&nbsp;
                  <a class="btn btn-warning" href="{{ url('create-diary') }}">Cancel</a>
               </div>
            </div>
         </div>
   </div>
   <!-- <hr class="mb-4">
      <button class="btn btn-primary btn-lg btn-block" type="submit">Continue to checkout</button>-->
   </form>
</div>
</div>

@include('include.footer') 
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script> </head>
<script type="text/javascript">
   var today = "<?php echo date('Y-m-d') ?>";
        $('#EntryDate').datepicker({
               format: "yyyy-mm-dd",
                endDate:today,
            });  
</script> 
<style> 
</style>
<script>
   var count = 0;
   function addmoretodo(){
    count += 1;     
    $(' <div class="row"><div class="col-md-1 kl1"> <label></label> <input type="checkbox" name="todostatusnews['+count+'][]" value="1">  </div><div class="col-md-11 mb-3"><input type="text" name="todotextnews['+count+'][]"  class="form-control"> </div>  </div>').appendTo('#Content');            
    
   }              
</script>
<script>
   var count = 0;
    function addmoreidea(){
    count += 1;  
    $('<div class="row"><div class="col-md-1 mb-3"><label></label><input type="checkbox" name="ideaatus['+count+'][]" value="1"></div><div class="col-md-11 mb-3"><input type="text" name="createiveidea['+count+'][]" class="form-control"> </div></div>').appendTo('#Contentidea');
    
   
   }
</script>
<script>
   var count = 0;
   function addmarketing(){
      count += 1; 
      $(' <div class="col-md-11 mb-3"><input type="text" name="marketing[]" class="form-control"></div>').appendTo("#marketdiv");
   }
</script>
<script>
   function addmorereport(){
      $(' <div class="col-md-11 mb-3"><input type="text" name="report[]" class="form-control"></div>').appendTo("#reportdiv");
   }
    
</script>
<script>
   function addmorenotes()
   {
      $(' <div class="col-md-11 mb-3"><input type="text" name="notes[]" class="form-control"></div>').appendTo("#notesdiv");
   }
    
</script>
<script>
   function addmorehome(){
   
      $(' <div class="col-md-11 mb-3"><input type="text" name="home[]" class="form-control"></div>').appendTo("#homediv");
   }
</script>
@endsection