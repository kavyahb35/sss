@extends('layout.inner')
@section('content')

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
   <h1 class="h2">Tag</h1>
   
</div>
<style>
  .bg-dark1{  margin-top: 50%; }
</style>
@include('include.footer')
<!--<canvas class="my-4" id="myChart" width="900" height="380"></canvas>-->

@endsection