<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDiaryEntryTodosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('diary_entry_todos', function (Blueprint $table) {
            $table->increments('Id');
            $table->integer('PredefinedNoteId')->nullable();            
            $table->integer('EntryId');           
            $table->text('Title')->nullable();
            $table->integer('IsActive')->nullable();
            $table->integer('PredefineType')->nullable();
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('diary_entry_todos');
    }
}
