-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2018 at 02:46 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cuiekdiary`
--

-- --------------------------------------------------------

--
-- Table structure for table `diary_entries`
--

CREATE TABLE `diary_entries` (
  `EntryId` int(10) UNSIGNED NOT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(11) NOT NULL,
  `PredefinedNoteId` int(11) DEFAULT NULL,
  `NoteText` text COLLATE utf8mb4_unicode_ci,
  `PredefineNoteType` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `diary_entry_todos`
--

CREATE TABLE `diary_entry_todos` (
  `Id` int(10) UNSIGNED NOT NULL,
  `PredefinedNoteId` int(11) DEFAULT NULL,
  `EntryId` int(11) NOT NULL,
  `Title` text COLLATE utf8mb4_unicode_ci,
  `IsActive` int(11) DEFAULT NULL,
  `PredefineType` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_09_01_000001_create_diary_entries_table', 1),
(2, '2018_09_01_000001_create_diary_entry_todos_table', 1),
(3, '2018_09_01_000001_create_note_types_table', 1),
(4, '2018_09_01_000001_create_predefined_notes_table', 1),
(5, '2018_09_01_000001_create_section_predefine_notes_table', 1),
(6, '2018_09_01_000001_create_sections_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `note_types`
--

CREATE TABLE `note_types` (
  `Id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `IsActive` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `note_types`
--

INSERT INTO `note_types` (`Id`, `Name`, `IsActive`) VALUES
(1, 'Simple note', 1),
(2, 'Simple note with status', 1),
(3, 'Predefine simple note', 1),
(4, 'Predefine note with status', 1);

-- --------------------------------------------------------

--
-- Table structure for table `predefined_notes`
--

CREATE TABLE `predefined_notes` (
  `id` int(10) UNSIGNED NOT NULL,
  `NoteTypeId` int(11) NOT NULL,
  `NoteText` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `IsActive` int(11) NOT NULL,
  `PredefinedNoteType` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `predefined_notes`
--

INSERT INTO `predefined_notes` (`id`, `NoteTypeId`, `NoteText`, `IsActive`, `PredefinedNoteType`) VALUES
(1, 4, 'Sit Straight', 1, 1),
(2, 4, 'Stretch Legs', 1, 1),
(3, 4, 'Do One Thing', 1, 1),
(4, 4, 'Eat Healthy', 1, 1),
(5, 4, 'Subway', 1, 1),
(6, 4, 'Exercise Daily', 1, 1),
(7, 4, 'Morning Rituals', 1, 1),
(8, 4, 'Daily Planner', 1, 1),
(9, 4, 'No Radio Listen to Good Radio', 1, 1),
(10, 4, 'Think Positive', 1, 1),
(11, 4, 'Habits', 1, 2),
(12, 4, 'Silence Mediation', 1, 2),
(13, 4, 'Alfirmation', 1, 2),
(14, 4, 'Visualization', 1, 2),
(15, 4, 'Exercise', 1, 2),
(16, 4, 'Reading', 1, 2),
(17, 4, 'Scribing', 1, 2),
(18, 4, 'Breakfast', 1, 2),
(19, 4, 'Snacks at 11', 1, 2),
(20, 4, 'Lunch at 1', 1, 2),
(21, 4, 'Snacks at 3', 1, 2),
(22, 4, 'Drink Water 4 liters', 1, 2),
(23, 4, 'Visualization', 1, 2),
(24, 4, 'Read routine', 1, 2),
(25, 4, 'Read goals', 1, 2),
(26, 4, 'Day Planner', 1, 2),
(27, 4, 'Kids homework', 1, 2),
(28, 4, 'Lifestyle', 1, 2),
(29, 4, 'Deposit  $50 in savings', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `id` int(10) UNSIGNED NOT NULL,
  `SectionTitle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `IsActive` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`id`, `SectionTitle`, `IsActive`) VALUES
(1, 'Habit', 1),
(2, 'Marketing', 1),
(3, 'To Do List', 1),
(4, 'Report', 1),
(5, 'Notes', 1),
(6, 'Creative ideas', 1),
(7, 'Routine Habit', 1),
(8, 'Secondary Habit', 1),
(9, 'Five things that i hate', 1),
(10, 'Five things that i am greatful for', 1),
(11, 'Home', 1);

-- --------------------------------------------------------

--
-- Table structure for table `section_predefine_notes`
--

CREATE TABLE `section_predefine_notes` (
  `id` int(10) UNSIGNED NOT NULL,
  `SectionId` int(11) NOT NULL,
  `PredefinedNoteId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `Id` int(10) UNSIGNED NOT NULL,
  `FirstName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `LastName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `IsActive` int(11) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`Id`, `FirstName`, `LastName`, `Email`, `Password`, `Slug`, `IsActive`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 'admin', 'admin@cueserve.com', 'Z3I4RGVzIWducw==', 'super-admin', 1, NULL, '2018-08-31 18:30:00', '2018-08-31 18:30:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `diary_entries`
--
ALTER TABLE `diary_entries`
  ADD PRIMARY KEY (`EntryId`);

--
-- Indexes for table `diary_entry_todos`
--
ALTER TABLE `diary_entry_todos`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `note_types`
--
ALTER TABLE `note_types`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `predefined_notes`
--
ALTER TABLE `predefined_notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `section_predefine_notes`
--
ALTER TABLE `section_predefine_notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `diary_entries`
--
ALTER TABLE `diary_entries`
  MODIFY `EntryId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `diary_entry_todos`
--
ALTER TABLE `diary_entry_todos`
  MODIFY `Id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `note_types`
--
ALTER TABLE `note_types`
  MODIFY `Id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `predefined_notes`
--
ALTER TABLE `predefined_notes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `section_predefine_notes`
--
ALTER TABLE `section_predefine_notes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `Id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
